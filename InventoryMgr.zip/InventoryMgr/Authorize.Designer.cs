﻿namespace InventoryMgr
{
    partial class Authorize
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Authorize));
            this.LabelServer = new System.Windows.Forms.Label();
            this.ButtonOK = new System.Windows.Forms.Button();
            this.ButtonCancel = new System.Windows.Forms.Button();
            this.ServerTextBox = new System.Windows.Forms.TextBox();
            this.IntegratedCheck = new System.Windows.Forms.CheckBox();
            this.DatabaseTextBox = new System.Windows.Forms.TextBox();
            this.DatabaseText = new System.Windows.Forms.Label();
            this.LockIcon = new System.Windows.Forms.PictureBox();
            this.LoginLabel = new System.Windows.Forms.Label();
            this.UsernameTextBox = new System.Windows.Forms.TextBox();
            this.LabelPassword = new System.Windows.Forms.Label();
            this.PasswordTextBox = new System.Windows.Forms.TextBox();
            this.LabelUsername = new System.Windows.Forms.Label();
            this.Seperator2 = new System.Windows.Forms.Label();
            this.PortNumberTextBox = new System.Windows.Forms.TextBox();
            this.PortNumberLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.InstanceTextBox = new System.Windows.Forms.TextBox();
            this.InstanceLabel = new System.Windows.Forms.Label();
            this.labelFAQ = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.LockIcon)).BeginInit();
            this.SuspendLayout();
            // 
            // LabelServer
            // 
            this.LabelServer.AutoSize = true;
            this.LabelServer.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelServer.Location = new System.Drawing.Point(32, 82);
            this.LabelServer.Name = "LabelServer";
            this.LabelServer.Size = new System.Drawing.Size(58, 15);
            this.LabelServer.TabIndex = 2;
            this.LabelServer.Text = "Tên miền:";
            // 
            // ButtonOK
            // 
            this.ButtonOK.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonOK.Location = new System.Drawing.Point(338, 267);
            this.ButtonOK.Name = "ButtonOK";
            this.ButtonOK.Size = new System.Drawing.Size(78, 25);
            this.ButtonOK.TabIndex = 3;
            this.ButtonOK.Text = "OK";
            this.ButtonOK.UseVisualStyleBackColor = true;
            this.ButtonOK.Click += new System.EventHandler(this.ButtonOK_Click);
            // 
            // ButtonCancel
            // 
            this.ButtonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.ButtonCancel.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonCancel.Location = new System.Drawing.Point(420, 267);
            this.ButtonCancel.Name = "ButtonCancel";
            this.ButtonCancel.Size = new System.Drawing.Size(78, 25);
            this.ButtonCancel.TabIndex = 4;
            this.ButtonCancel.Text = "Hủy";
            this.ButtonCancel.UseVisualStyleBackColor = true;
            this.ButtonCancel.Click += new System.EventHandler(this.ButtonCancel_Click);
            // 
            // ServerTextBox
            // 
            this.ServerTextBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ServerTextBox.Location = new System.Drawing.Point(92, 79);
            this.ServerTextBox.Name = "ServerTextBox";
            this.ServerTextBox.Size = new System.Drawing.Size(285, 23);
            this.ServerTextBox.TabIndex = 5;
            this.ServerTextBox.Text = "LOCALHOST";
            this.ServerTextBox.WordWrap = false;
            // 
            // IntegratedCheck
            // 
            this.IntegratedCheck.AutoSize = true;
            this.IntegratedCheck.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IntegratedCheck.Location = new System.Drawing.Point(18, 155);
            this.IntegratedCheck.Name = "IntegratedCheck";
            this.IntegratedCheck.Size = new System.Drawing.Size(144, 19);
            this.IntegratedCheck.TabIndex = 8;
            this.IntegratedCheck.Text = "Xác thực cục bộ (SSPI)";
            this.IntegratedCheck.UseVisualStyleBackColor = true;
            this.IntegratedCheck.CheckedChanged += new System.EventHandler(this.IntegratedCheck_CheckedChanged);
            // 
            // DatabaseTextBox
            // 
            this.DatabaseTextBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DatabaseTextBox.Location = new System.Drawing.Point(342, 117);
            this.DatabaseTextBox.Name = "DatabaseTextBox";
            this.DatabaseTextBox.Size = new System.Drawing.Size(129, 23);
            this.DatabaseTextBox.TabIndex = 14;
            this.DatabaseTextBox.Text = "TheInventory";
            this.DatabaseTextBox.WordWrap = false;
            // 
            // DatabaseText
            // 
            this.DatabaseText.AutoSize = true;
            this.DatabaseText.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DatabaseText.Location = new System.Drawing.Point(257, 120);
            this.DatabaseText.Name = "DatabaseText";
            this.DatabaseText.Size = new System.Drawing.Size(79, 15);
            this.DatabaseText.TabIndex = 13;
            this.DatabaseText.Text = "Cơ sở dữ liệu:";
            // 
            // LockIcon
            // 
            this.LockIcon.Image = global::InventoryMgr.Properties.Resources.keylock;
            this.LockIcon.Location = new System.Drawing.Point(441, 0);
            this.LockIcon.Name = "LockIcon";
            this.LockIcon.Size = new System.Drawing.Size(57, 64);
            this.LockIcon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.LockIcon.TabIndex = 15;
            this.LockIcon.TabStop = false;
            // 
            // LoginLabel
            // 
            this.LoginLabel.AutoSize = true;
            this.LoginLabel.Font = new System.Drawing.Font("Segoe UI Semibold", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.LoginLabel.ForeColor = System.Drawing.SystemColors.Highlight;
            this.LoginLabel.Location = new System.Drawing.Point(12, 15);
            this.LoginLabel.Name = "LoginLabel";
            this.LoginLabel.Size = new System.Drawing.Size(330, 32);
            this.LoginLabel.TabIndex = 17;
            this.LoginLabel.Text = "Đăng nhập vào Máy chủ SQL";
            // 
            // UsernameTextBox
            // 
            this.UsernameTextBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UsernameTextBox.Location = new System.Drawing.Point(229, 182);
            this.UsernameTextBox.Name = "UsernameTextBox";
            this.UsernameTextBox.Size = new System.Drawing.Size(242, 23);
            this.UsernameTextBox.TabIndex = 7;
            this.UsernameTextBox.Text = "sa";
            this.UsernameTextBox.WordWrap = false;
            // 
            // LabelPassword
            // 
            this.LabelPassword.AutoSize = true;
            this.LabelPassword.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelPassword.Location = new System.Drawing.Point(89, 221);
            this.LabelPassword.Name = "LabelPassword";
            this.LabelPassword.Size = new System.Drawing.Size(60, 15);
            this.LabelPassword.TabIndex = 1;
            this.LabelPassword.Text = "Mật khẩu:";
            // 
            // PasswordTextBox
            // 
            this.PasswordTextBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PasswordTextBox.Location = new System.Drawing.Point(229, 218);
            this.PasswordTextBox.Name = "PasswordTextBox";
            this.PasswordTextBox.PasswordChar = '*';
            this.PasswordTextBox.Size = new System.Drawing.Size(242, 23);
            this.PasswordTextBox.TabIndex = 6;
            this.PasswordTextBox.UseSystemPasswordChar = true;
            this.PasswordTextBox.WordWrap = false;
            // 
            // LabelUsername
            // 
            this.LabelUsername.AutoSize = true;
            this.LabelUsername.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelUsername.Location = new System.Drawing.Point(89, 185);
            this.LabelUsername.Name = "LabelUsername";
            this.LabelUsername.Size = new System.Drawing.Size(93, 15);
            this.LabelUsername.TabIndex = 0;
            this.LabelUsername.Text = "Tên người dùng:";
            // 
            // Seperator2
            // 
            this.Seperator2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Seperator2.Location = new System.Drawing.Point(12, 62);
            this.Seperator2.Name = "Seperator2";
            this.Seperator2.Size = new System.Drawing.Size(487, 2);
            this.Seperator2.TabIndex = 18;
            // 
            // PortNumberTextBox
            // 
            this.PortNumberTextBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PortNumberTextBox.Location = new System.Drawing.Point(420, 79);
            this.PortNumberTextBox.Name = "PortNumberTextBox";
            this.PortNumberTextBox.Size = new System.Drawing.Size(51, 23);
            this.PortNumberTextBox.TabIndex = 20;
            this.PortNumberTextBox.Text = "1433";
            this.PortNumberTextBox.WordWrap = false;
            // 
            // PortNumberLabel
            // 
            this.PortNumberLabel.AutoSize = true;
            this.PortNumberLabel.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PortNumberLabel.Location = new System.Drawing.Point(380, 82);
            this.PortNumberLabel.Name = "PortNumberLabel";
            this.PortNumberLabel.Size = new System.Drawing.Size(39, 15);
            this.PortNumberLabel.TabIndex = 19;
            this.PortNumberLabel.Text = "Cổng:";
            // 
            // label1
            // 
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Location = new System.Drawing.Point(16, 257);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(487, 2);
            this.label1.TabIndex = 21;
            // 
            // InstanceTextBox
            // 
            this.InstanceTextBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InstanceTextBox.Location = new System.Drawing.Point(92, 117);
            this.InstanceTextBox.Name = "InstanceTextBox";
            this.InstanceTextBox.Size = new System.Drawing.Size(159, 23);
            this.InstanceTextBox.TabIndex = 25;
            this.InstanceTextBox.Text = "SQLEXPRESS";
            this.InstanceTextBox.WordWrap = false;
            // 
            // InstanceLabel
            // 
            this.InstanceLabel.AutoSize = true;
            this.InstanceLabel.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InstanceLabel.Location = new System.Drawing.Point(32, 120);
            this.InstanceLabel.Name = "InstanceLabel";
            this.InstanceLabel.Size = new System.Drawing.Size(54, 15);
            this.InstanceLabel.TabIndex = 24;
            this.InstanceLabel.Text = "Bản SQL:";
            // 
            // labelFAQ
            // 
            this.labelFAQ.AutoSize = true;
            this.labelFAQ.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelFAQ.Location = new System.Drawing.Point(15, 272);
            this.labelFAQ.Name = "labelFAQ";
            this.labelFAQ.Size = new System.Drawing.Size(267, 15);
            this.labelFAQ.TabIndex = 26;
            this.labelFAQ.Text = "Vấn đề đăng nhập? Nhấn nút ? để được trợ giúp.";
            // 
            // Authorize
            // 
            this.AcceptButton = this.ButtonOK;
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.CancelButton = this.ButtonCancel;
            this.ClientSize = new System.Drawing.Size(510, 305);
            this.Controls.Add(this.labelFAQ);
            this.Controls.Add(this.InstanceTextBox);
            this.Controls.Add(this.InstanceLabel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.PortNumberTextBox);
            this.Controls.Add(this.PortNumberLabel);
            this.Controls.Add(this.Seperator2);
            this.Controls.Add(this.LoginLabel);
            this.Controls.Add(this.LockIcon);
            this.Controls.Add(this.DatabaseTextBox);
            this.Controls.Add(this.DatabaseText);
            this.Controls.Add(this.IntegratedCheck);
            this.Controls.Add(this.UsernameTextBox);
            this.Controls.Add(this.PasswordTextBox);
            this.Controls.Add(this.ServerTextBox);
            this.Controls.Add(this.ButtonCancel);
            this.Controls.Add(this.ButtonOK);
            this.Controls.Add(this.LabelServer);
            this.Controls.Add(this.LabelPassword);
            this.Controls.Add(this.LabelUsername);
            this.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.HelpButton = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Authorize";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Xác thực";
            this.HelpButtonClicked += new System.ComponentModel.CancelEventHandler(this.Authorize_HelpButtonClicked);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Authorize_FormClosed);
            this.Load += new System.EventHandler(this.Authorize_Load);
            ((System.ComponentModel.ISupportInitialize)(this.LockIcon)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label LabelServer;
        private System.Windows.Forms.Button ButtonOK;
        private System.Windows.Forms.Button ButtonCancel;
        private System.Windows.Forms.TextBox ServerTextBox;
        private System.Windows.Forms.CheckBox IntegratedCheck;
        private System.Windows.Forms.TextBox DatabaseTextBox;
        private System.Windows.Forms.Label DatabaseText;
        private System.Windows.Forms.PictureBox LockIcon;
        private System.Windows.Forms.Label LoginLabel;
        private System.Windows.Forms.TextBox UsernameTextBox;
        private System.Windows.Forms.Label LabelPassword;
        private System.Windows.Forms.TextBox PasswordTextBox;
        private System.Windows.Forms.Label LabelUsername;
        private System.Windows.Forms.Label Seperator2;
        private System.Windows.Forms.TextBox PortNumberTextBox;
        private System.Windows.Forms.Label PortNumberLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox InstanceTextBox;
        private System.Windows.Forms.Label InstanceLabel;
        private System.Windows.Forms.Label labelFAQ;
    }
}