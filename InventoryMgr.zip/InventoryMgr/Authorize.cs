﻿using System;
using System.ComponentModel;
using System.Windows.Forms;

namespace InventoryMgr
{
    public partial class Authorize : Form
    {
        public Authorize()
        {
            InitializeComponent();
        }

        MainActivity mainactivityform = new MainActivity();
        private void LogicCheck()
        {
            if (DatabaseLogic.DatabaseConnectionState == "Open")
            {
                MessageBox.Show("Đã kết nối tới cơ sở dữ liệu và đăng nhập thành công.", "Trạng thái kết nối", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Globals.IsLoggedIn = true;
                mainactivityform.Show();
                this.Close();
            }
            else if (DatabaseLogic.DatabaseConnectionState == "Closed")
            {
                MessageBox.Show("Đã ngắt kết nối khỏi cơ sở dữ liệu. Bạn đã đăng xuất.", "Trạng thái kết nối", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            // This doesn't mean i'll catch errors.
            else
            {
                if (Globals.IsLoggedIn)
                {
                    MessageBox.Show("Chưa xác định được trạng thái kết nối.\nBạn vẫn đang đăng nhập.", "Trạng thái kết nối", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                if (Globals.IsLoggedIn == false)
                {
                    MessageBox.Show("Chưa xác định được trạng thái kết nối.\nBạn vẫn bị đăng xuất.", "Trạng thái kết nối", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        private void ButtonOK_Click(object sender, EventArgs e)
        {
            DatabaseLogic.SqlServer = ServerTextBox.Text;
            DatabaseLogic.SqlInstance = InstanceTextBox.Text;
            DatabaseLogic.SqlDatabaseName = DatabaseTextBox.Text;
            DatabaseLogic.SqlUsername = UsernameTextBox.Text;
            DatabaseLogic.SqlPortNo = PortNumberTextBox.Text;
            DatabaseLogic.SqlPassword = PasswordTextBox.Text;
            DatabaseLogic databaseLogic = new DatabaseLogic();
            if (IntegratedCheck.Checked)
            {
                if (ServerTextBox.Text == "" || PortNumberTextBox.Text == "" || DatabaseTextBox.Text == "" || InstanceTextBox.Text == "")
                {
                    MessageBox.Show("Bạn phải điền mọi thứ trước khi bạn có thể đăng nhập.", "Không được", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    DatabaseLogic.SqlIntgSec = "SSPI";
                    DatabaseLogic.ConnectionString = $@"Server={DatabaseLogic.SqlServer}\{DatabaseLogic.SqlInstance},{DatabaseLogic.SqlPortNo};Network Library={DatabaseLogic.SqlNwkLib};Database={DatabaseLogic.SqlDatabaseName};Integrated Security={DatabaseLogic.SqlIntgSec}";

                    try
                    {
                        databaseLogic.OpenConnection();
                    }
                    catch (Exception exception)
                    {
                        if (exception != null)
                        {
                            MessageBox.Show(exception.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    LogicCheck();
                }
            }
            else
            {
                if (ServerTextBox.Text == "" || PortNumberTextBox.Text == "" || DatabaseTextBox.Text == "" || InstanceTextBox.Text == "" || UsernameTextBox.Text == "" || PasswordTextBox.Text == "")
                {
                    MessageBox.Show("Bạn phải điền mọi thứ trước khi bạn có thể đăng nhập. Và dùng mật khẩu trống là một thói quen xấu.\n\nVui lòng liên hệ quản trị viên và thử lại sau.", "Không được", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    DatabaseLogic.ConnectionString = $@"Server={DatabaseLogic.SqlServer}\{DatabaseLogic.SqlInstance},{DatabaseLogic.SqlPortNo};Network Library={DatabaseLogic.SqlNwkLib};Database={DatabaseLogic.SqlDatabaseName};User ID={DatabaseLogic.SqlUsername};Password={DatabaseLogic.SqlPassword};Integrated Security={DatabaseLogic.SqlIntgSec}";
                    try
                    {
                        databaseLogic.OpenConnection();
                    }
                    catch (Exception exception)
                    {
                        if (exception != null)
                        {
                            MessageBox.Show(exception.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    LogicCheck();
                }
            }
        }

        private void ButtonCancel_Click(object sender, EventArgs e)
        {
            mainactivityform.Show();
            this.Close();
        }

        private void IntegratedCheck_CheckedChanged(object sender, EventArgs e)
        {
            if (IntegratedCheck.Checked)
            {
                UsernameTextBox.Enabled = false;
                PasswordTextBox.Enabled = false;
            }
            else
            {
                UsernameTextBox.Enabled = true;
                PasswordTextBox.Enabled = true;
            }
        }

        private void Authorize_Load(object sender, EventArgs e)
        {
            IntegratedCheck.Checked = true;
        }


        private void Authorize_FormClosed(object sender, FormClosedEventArgs e)
        {
            mainactivityform.Show();
            this.Close();
        }

        private void Authorize_HelpButtonClicked(object sender, CancelEventArgs e)
        {
            MessageBox.Show("Trước khi bạn có thể đăng nhập cục bộ hoặc từ xa, hãy thao tác các bước sau:\n\nMở Trình quản lý Cấu hình Máy chủ SQL > Cấu hình mạng Máy chủ SQL > Giao thức cho [Bản SQL của bạn] > TCP/IP > Địa chỉ IP > IP[x] (Ưu tiên IPAll) > Cổng TCP > Điền cổng 1433 hoặc bất cứ cổng nào bạn muốn.\n\nKhởi động lại Bản SQL của bạn và bạn có thể đăng nhập được.\n\nĐối với đăng nhập từ xa. Vui lòng kiểm tra chứng chỉ SSL (Nếu bạn dùng phiên bản cũ của Windows) và Luật của Tường lửa.", "Trợ giúp", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //  This should work but it doesn't?
            Cursor.Current = Cursors.Default;
        }
    }
}
