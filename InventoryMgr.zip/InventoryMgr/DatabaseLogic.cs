﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace InventoryMgr
{
    public class DatabaseLogic
    {
        public SqlConnection DatabaseConnection = null;
        public static string SqlUsername = @"sa";
        //  According to Google it's blank but you should use integrated security instead.
        public static string SqlPassword = "Not initialized";
        public static string SqlServer = "Not initialized";
        public static string SqlDatabaseName = "Not initialized";
        public static string SqlPortNo = "Not initialized";
        public static string SqlInstance = "Not initialized";
        public static string SqlIntgSec = "false";
        public static string SqlNwkLib = "DBMSSOCN";
        //  false for Adding Records and true for Editing mode.
        public static bool SqlEditingMode = false;
        public static string ConnectionString = @"null";
        public static string SqlOperationString = "Not initialized";
        public static string SqlColName = "Not initialized";
        public static string SqlTableName = "Not initialized";
        public static string DatabaseConnectionState = "Not initialized";
        public static string SearchQuery;
        public static string SearchQueryCurrentTable;
        public void OpenConnection()
        {
            if (DatabaseConnection == null)
            {
                DatabaseConnection = new SqlConnection(ConnectionString);
            }

            if (DatabaseConnection.State == ConnectionState.Closed)
            {
                DatabaseConnection.Open();
            }
            DatabaseConnectionState = DatabaseConnection.State.ToString();
        }
        public void CloseConnection()
        {
            if (DatabaseConnection != null && DatabaseConnection.State == ConnectionState.Open)
            {
                DatabaseConnection.Close();
            }
            DatabaseConnectionState = DatabaseConnection.State.ToString();
        }

        public void CheckEditMode()
        {

            if (DatabaseLogic.SqlEditingMode == true)
            {
                DatabaseLogic.SqlOperationString = "UPDATE";
            }
            if (DatabaseLogic.SqlEditingMode == false)
            {
                DatabaseLogic.SqlOperationString = "INSERT INTO";
            }
        }
        //  This "Products" Refers to DatabaseValues.cs
        public List<Products> GetProductsTable()
        {
            SqlCommand DatabaseCommand = new SqlCommand();
            List<Products> list = new List<Products>();
            OpenConnection();
            DatabaseCommand.CommandType = CommandType.Text;
            //  Don't forget to edit the same table query name as well in SQL
            DatabaseCommand.CommandText = $"SELECT * FROM {SqlTableName}";
            DatabaseCommand.Connection = DatabaseConnection;
            SqlDataReader DatabaseReader = DatabaseCommand.ExecuteReader();
            while (DatabaseReader.Read())
            {
                //  Define them as exactly like DatabaseLogic.cs
                int ProductID = DatabaseReader.GetInt32(0);
                string ProductName = DatabaseReader.GetString(1);
                string ProductSKU = DatabaseReader.GetString(2);
                Int16 ProductQuantity = DatabaseReader.GetInt16(3);
                Decimal ProductPrice = DatabaseReader.GetDecimal(4);
                int ProductStaffIDProvision = DatabaseReader.GetInt32(5);
                DateTime ProductExpiryDate = DatabaseReader.GetDateTime(6);
                DateTime ProductImportDate = DatabaseReader.GetDateTime(7);
                //  Arguements also in DatabaseLogic.cs
                Products SqlProductsTable = new Products(ProductID, ProductName, ProductSKU, ProductQuantity, ProductPrice, ProductStaffIDProvision, ProductExpiryDate, ProductImportDate);
                list.Add(SqlProductsTable);
            }
            CloseConnection();
            DatabaseReader.Close();
            return list;
        }
        //  This "Clients" Refers to DatabaseValues.cs
        public List<Clients> GetClientsTable()
        {
            SqlCommand DatabaseCommand = new SqlCommand();
            List<Clients> list = new List<Clients>();
            OpenConnection();
            DatabaseCommand.CommandType = CommandType.Text;
            //  Don't forget to edit the same table query name as well in SQL
            DatabaseCommand.CommandText = $"SELECT * FROM {SqlTableName}";
            DatabaseCommand.Connection = DatabaseConnection;
            SqlDataReader DatabaseReader = DatabaseCommand.ExecuteReader();
            while (DatabaseReader.Read())
            {
                //  Define them as exactly like DatabaseLogic.cs
                int ClientID = DatabaseReader.GetInt32(0);
                string ClientName = DatabaseReader.GetString(1);
                DateTime ClientBirthday = DatabaseReader.GetDateTime(2);
                string ClientAddress = DatabaseReader.GetString(3);
                string ClientPhone = DatabaseReader.GetString(4);
                string ClientEmail = DatabaseReader.GetString(5);
                string ClientNotes = DatabaseReader.GetString(6);

                //  Arguements also in DatabaseLogic.cs
                Clients SqlClientsTable = new Clients(ClientID, ClientName, ClientBirthday, ClientAddress, ClientPhone, ClientEmail, ClientNotes);
                list.Add(SqlClientsTable);
            }
            CloseConnection();
            DatabaseReader.Close();
            return list;
        }
        //  This "Staff" Refers to DatabaseValues.cs
        public List<Staff> GetStaffTable()
        {
            SqlCommand DatabaseCommand = new SqlCommand();
            List<Staff> list = new List<Staff>();
            OpenConnection();
            DatabaseCommand.CommandType = CommandType.Text;
            //  Don't forget to edit the same table query name as well in SQL
            DatabaseCommand.CommandText = $"SELECT * FROM {SqlTableName}";
            DatabaseCommand.Connection = DatabaseConnection;
            SqlDataReader DatabaseReader = DatabaseCommand.ExecuteReader();
            while (DatabaseReader.Read())
            {
                //  Define them as exactly like DatabaseLogic.cs
                int StaffID = DatabaseReader.GetInt32(0);
                Boolean IsStaffAdmin = DatabaseReader.GetBoolean(1);
                string StaffName = DatabaseReader.GetString(2);
                DateTime StaffBirthday = DatabaseReader.GetDateTime(3);
                string StaffAddress = DatabaseReader.GetString(4);
                string StaffPhone = DatabaseReader.GetString(5);
                string StaffEmail = DatabaseReader.GetString(6);
                string StaffNotes = DatabaseReader.GetString(7);

                //  Arguements also in DatabaseLogic.cs
                Staff SqlClientsTable = new Staff(StaffID, IsStaffAdmin, StaffName, StaffBirthday, StaffAddress, StaffPhone, StaffEmail, StaffNotes);
                list.Add(SqlClientsTable);
            }
            CloseConnection();
            DatabaseReader.Close();
            return list;
        }
        //  This "Products" Refers to DatabaseValues.cs
        public void ModifyProductsTable(Products ProductTableClass)
        {
            OpenConnection();
            CheckEditMode();
            SqlCommand DatabaseCommand = new SqlCommand();
            if (DatabaseLogic.SqlEditingMode == false)
            {
                DatabaseCommand.CommandText = $"{DatabaseLogic.SqlOperationString} {DatabaseLogic.SqlTableName} VALUES (@ProductID, @ProductName, @ProductSKU, @ProductQuantity, @ProductPrice, @ProductStaffIDProvision, @ProductExpiryDate, @ProductImportDate)";
            }
            else
            {
                DatabaseCommand.CommandText = $"{DatabaseLogic.SqlOperationString} {DatabaseLogic.SqlTableName} SET ProductName = @ProductName, ProductSKU = @ProductSKU, ProductQuantity = @ProductQuantity, ProductPrice = @ProductPrice, ProductStaffIDProvision = @ProductStaffIDProvision, ProductExpiryDate = @ProductExpiryDate, ProductImportDate = @ProductImportDate WHERE ProductID = @ProductID";
            }
            DatabaseCommand.CommandType = CommandType.Text;
            DatabaseCommand.Connection = DatabaseConnection;
            //  Define these SQL Database Type data type just like the Table.
            DatabaseCommand.Parameters.Add("@ProductID", SqlDbType.Int).Value = ProductTableClass.ProductID;
            DatabaseCommand.Parameters.Add("@ProductName", SqlDbType.NVarChar).Value = ProductTableClass.ProductName;
            DatabaseCommand.Parameters.Add("@ProductSKU", SqlDbType.VarChar).Value = ProductTableClass.ProductSKU;
            DatabaseCommand.Parameters.Add("@ProductQuantity", SqlDbType.SmallInt).Value = ProductTableClass.ProductQuantity;
            DatabaseCommand.Parameters.Add("@ProductPrice", SqlDbType.Money).Value = ProductTableClass.ProductPrice;
            DatabaseCommand.Parameters.Add("@ProductStaffIDProvision", SqlDbType.Int).Value = ProductTableClass.ProductStaffIDProvision;
            DatabaseCommand.Parameters.Add("@ProductExpiryDate", SqlDbType.Date).Value = ProductTableClass.ProductExpiryDate;
            DatabaseCommand.Parameters.Add("@ProductImportDate", SqlDbType.Date).Value = ProductTableClass.ProductImportDate;
            try
            {
                DatabaseCommand.ExecuteNonQuery();
                MessageBox.Show("Hoàn tất.", "Thông tin", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (SqlException exception)
            {
                if (exception != null)
                {
                    MessageBox.Show(exception.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            DatabaseLogic.SqlEditingMode = false;
            CloseConnection();
        }
        //  This "Staff" Refers to DatabaseValues.cs
        public void ModifyStaffTable(Staff StaffClass)
        {
            OpenConnection();
            CheckEditMode();
            SqlCommand DatabaseCommand = new SqlCommand();

            if (DatabaseLogic.SqlEditingMode == false)
            {
                DatabaseCommand.CommandText = $"{DatabaseLogic.SqlOperationString} {DatabaseLogic.SqlTableName} VALUES (@StaffID, @StaffIsAdmin, @StaffName, @StaffBirthday, @StaffAddress, @StaffPhone, @StaffEmail, @StaffNotes)";
            }
            else
            {
                DatabaseCommand.CommandText = $"{DatabaseLogic.SqlOperationString} {DatabaseLogic.SqlTableName} SET StaffIsAdmin = @StaffIsAdmin, StaffName = @StaffName, StaffBirthday = @StaffBirthday, StaffAddress = @StaffAddress, StaffPhone = @StaffPhone, StaffEmail = @StaffEmail, StaffNotes = @StaffNotes WHERE StaffID = @StaffID";
            }
            DatabaseCommand.CommandType = CommandType.Text;
            DatabaseCommand.Connection = DatabaseConnection;
            //  Define these SQL Database Type data type just like the Table.
            DatabaseCommand.Parameters.Add("@StaffID", SqlDbType.Int).Value = StaffClass.StaffID;
            DatabaseCommand.Parameters.Add("@StaffIsAdmin", SqlDbType.Bit).Value = StaffClass.StaffIsAdmin;
            DatabaseCommand.Parameters.Add("@StaffName", SqlDbType.NVarChar).Value = StaffClass.StaffName;
            DatabaseCommand.Parameters.Add("@StaffBirthday", SqlDbType.Date).Value = StaffClass.StaffBirthday;
            DatabaseCommand.Parameters.Add("@StaffAddress", SqlDbType.NVarChar).Value = StaffClass.StaffAddress;
            DatabaseCommand.Parameters.Add("@StaffPhone", SqlDbType.VarChar).Value = StaffClass.StaffPhone;
            DatabaseCommand.Parameters.Add("@StaffEmail", SqlDbType.VarChar).Value = StaffClass.StaffEmail;
            DatabaseCommand.Parameters.Add("@StaffNotes", SqlDbType.NVarChar).Value = StaffClass.StaffNotes;
            try
            {
                DatabaseCommand.ExecuteNonQuery();
                MessageBox.Show("Hoàn tất.", "Thông tin", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (SqlException exception)
            {
                if (exception != null)
                {
                    MessageBox.Show(exception.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            DatabaseLogic.SqlEditingMode = false;
            CloseConnection();
        }
        //  This "Clients" Refers to DatabaseValues.cs
        public void ModifyClientsTable(Clients ClientsClass)
        {
            OpenConnection();
            CheckEditMode();
            SqlCommand DatabaseCommand = new SqlCommand();
            if (DatabaseLogic.SqlEditingMode == false)
            {
                DatabaseCommand.CommandText = $"{DatabaseLogic.SqlOperationString} {DatabaseLogic.SqlTableName} VALUES (@ClientID, @ClientName, @ClientBirthday, @ClientAddress, @ClientPhone, @ClientEmail, @ClientNotes)";
            }
            else
            {
                DatabaseCommand.CommandText = $"{DatabaseLogic.SqlOperationString} {DatabaseLogic.SqlTableName} SET ClientName = @ClientName, ClientBirthday = @ClientBirthday, ClientAddress = @ClientAddress, ClientPhone = @ClientPhone, ClientEmail = @ClientEmail, ClientNotes = @ClientNotes WHERE ClientID = @ClientID";
            }
            DatabaseCommand.CommandType = CommandType.Text;
            DatabaseCommand.Connection = DatabaseConnection;
            //  Define these SQL Database Type data type just like the Table.
            DatabaseCommand.Parameters.Add("@ClientID", SqlDbType.Int).Value = ClientsClass.ClientID;
            DatabaseCommand.Parameters.Add("@ClientName", SqlDbType.NVarChar).Value = ClientsClass.ClientName;
            DatabaseCommand.Parameters.Add("@ClientBirthday", SqlDbType.Date).Value = ClientsClass.ClientBirthday;
            DatabaseCommand.Parameters.Add("@ClientAddress", SqlDbType.NVarChar).Value = ClientsClass.ClientAddress;
            DatabaseCommand.Parameters.Add("@ClientPhone", SqlDbType.VarChar).Value = ClientsClass.ClientPhone;
            DatabaseCommand.Parameters.Add("@ClientEmail", SqlDbType.VarChar).Value = ClientsClass.ClientEmail;
            DatabaseCommand.Parameters.Add("@ClientNotes", SqlDbType.NVarChar).Value = ClientsClass.ClientNotes;
            try
            {
                DatabaseCommand.ExecuteNonQuery();
                MessageBox.Show("Hoàn tất.", "Thông tin", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (SqlException exception)
            {
                if (exception != null)
                {
                    MessageBox.Show(exception.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            DatabaseLogic.SqlEditingMode = false;
            CloseConnection();
        }
        //  "TablesID" refers to ClientID, StaffID or ProductID etc.
        public void DeleteRecord(string TablesIDString)
        {
            OpenConnection();
            SqlCommand DatabaseCommand = new SqlCommand();
            DatabaseCommand.CommandType = CommandType.Text;
            DatabaseCommand.Connection = DatabaseConnection;
            DatabaseCommand.Parameters.Add("@TablesIDString", SqlDbType.Int).Value = TablesIDString;
            DatabaseCommand.CommandText = $"DELETE FROM {DatabaseLogic.SqlTableName} WHERE {DatabaseLogic.SqlColName}=@TablesIDString";
            try
            {
                DatabaseCommand.ExecuteNonQuery();
                MessageBox.Show("Đã xóa.", "Thông tin", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (SqlException exception)
            {
                if (exception != null)
                {
                    MessageBox.Show(exception.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            CloseConnection();
        }
        //  This is super experimental. Should not be used.
        public void SearchRecord()
        {
            OpenConnection();
            SqlCommand DatabaseCommand = new SqlCommand();
            SqlDataAdapter DatabaseAdapter = new SqlDataAdapter(DatabaseCommand);
            DatabaseCommand.CommandType = CommandType.Text;
            DatabaseCommand.CommandText = DatabaseLogic.SearchQuery;
            DatabaseCommand.Connection = DatabaseConnection;
            DatabaseCommand.ExecuteNonQuery();

            using (DataTable dataTable = new DataTable(SearchQueryCurrentTable))
            {
                DatabaseAdapter.Fill(dataTable);
                using (SearchResults searchResultsForm = new SearchResults(dataTable))
                {
                    searchResultsForm.ShowDialog();
                }
            }
            CloseConnection();

        }
    }
}
