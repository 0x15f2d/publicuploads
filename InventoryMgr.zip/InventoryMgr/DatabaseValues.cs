﻿using System;

namespace InventoryMgr
{
    public class Products
    {
        private int _ProductID, _ProductStaffIDProvision;
        private Int16 _ProductQuantity;
        private string _ProductName, _ProductSKU;
        private Decimal _ProductPrice;
        private DateTime _ProductImportDate, _ProductExpiryDate;

        public int ProductID { get => _ProductID; set => _ProductID = value; }
        public Int16 ProductQuantity { get => _ProductQuantity; set => _ProductQuantity = value; }
        public int ProductStaffIDProvision { get => _ProductStaffIDProvision; set => _ProductStaffIDProvision = value; }
        public string ProductName { get => _ProductName; set => _ProductName = value; }
        public string ProductSKU { get => _ProductSKU; set => _ProductSKU = value; }
        public Decimal ProductPrice { get => _ProductPrice; set => _ProductPrice = value; }
        public DateTime ProductImportDate { get => _ProductImportDate; set => _ProductImportDate = value; }
        public DateTime ProductExpiryDate { get => _ProductExpiryDate; set => _ProductExpiryDate = value; }

        public Products() { }
        public Products(int ProductID, string ProductName, string ProductSKU, Int16 ProductQuantity, Decimal ProductPrice, int ProductStaffIDProvision, DateTime ProductExpiryDate, DateTime ProductImportDate)
        {
            this._ProductID = ProductID;
            this._ProductName = ProductName;
            this._ProductSKU = ProductSKU;
            this._ProductQuantity = ProductQuantity;
            this._ProductPrice = ProductPrice;
            this._ProductStaffIDProvision = ProductStaffIDProvision;
            this._ProductExpiryDate = ProductExpiryDate;
            this._ProductImportDate = ProductImportDate;
        }
    }

    public class Staff
    {
        private int _StaffID;
        private Boolean _StaffIsAdmin;
        private string _StaffName, _StaffAddress, _StaffPhone, _StaffEmail, _StaffNotes;
        private DateTime _StaffBirthday;
        public int StaffID { get => _StaffID; set => _StaffID = value; }
        public Boolean StaffIsAdmin { get => _StaffIsAdmin; set => _StaffIsAdmin = value; }
        public string StaffName { get => _StaffName; set => _StaffName = value; }
        public string StaffAddress { get => _StaffAddress; set => _StaffAddress = value; }
        public string StaffPhone { get => _StaffPhone; set => _StaffPhone = value; }
        public string StaffEmail { get => _StaffEmail; set => _StaffEmail = value; }
        public string StaffNotes { get => _StaffNotes; set => _StaffNotes = value; }
        public DateTime StaffBirthday { get => _StaffBirthday; set => _StaffBirthday = value; }
        public Staff() { }
        public Staff(int StaffID, Boolean StaffIsAdmin, string StaffName, DateTime StaffBirthday, string StaffAddress, string StaffPhone, string StaffEmail, string StaffNotes)
        {
            this._StaffID = StaffID;
            this._StaffIsAdmin = StaffIsAdmin;
            this._StaffName = StaffName;
            this._StaffBirthday = StaffBirthday;
            this._StaffAddress = StaffAddress;
            this._StaffPhone = StaffPhone;
            this._StaffEmail = StaffEmail;
            this._StaffNotes = StaffNotes;
        }

    }

    public class Clients
    {
        private int _ClientID;
        private string _ClientName, _ClientAddress, _ClientPhone, _ClientEmail, _ClientNotes;
        private DateTime _ClientBirthday;
        public int ClientID { get => _ClientID; set => _ClientID = value; }
        public string ClientName { get => _ClientName; set => _ClientName = value; }
        public string ClientAddress { get => _ClientAddress; set => _ClientAddress = value; }
        public string ClientPhone { get => _ClientPhone; set => _ClientPhone = value; }
        public string ClientEmail { get => _ClientEmail; set => _ClientEmail = value; }
        public string ClientNotes { get => _ClientNotes; set => _ClientNotes = value; }
        public DateTime ClientBirthday { get => _ClientBirthday; set => _ClientBirthday = value; }
        public Clients() { }
        public Clients(int ClientID, string ClientName, DateTime ClientBirthday, string ClientAddress, string ClientPhone, string ClientEmail, string ClientNotes)
        {
            this._ClientID = ClientID;
            this._ClientName = ClientName;
            this._ClientBirthday = ClientBirthday;
            this._ClientAddress = ClientAddress;
            this._ClientPhone = ClientPhone;
            this._ClientEmail = ClientEmail;
            this._ClientNotes = ClientNotes;
        }

    }
}
