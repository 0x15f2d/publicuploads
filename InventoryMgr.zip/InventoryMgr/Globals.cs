﻿namespace InventoryMgr
{
    public class Globals
    {
        public static bool IsLoggedIn = false;
        public static string ConnectionStatus;
        public static bool IsTableProducts = false;
        public static bool IsTableStaff = false;
        public static bool IsTableClients = false;
        public static bool SearchBoxAlwaysHide = false;
    }
}
