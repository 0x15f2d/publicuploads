﻿using System;

namespace InventoryMgr
{
    partial class MainActivity
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainActivity));
            this.MenuStrip = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.viewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuItem1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.menuItem2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuItem3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loginToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loginToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.logoutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.getTheSampleSQLScriptToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.labelLanding = new System.Windows.Forms.Label();
            this.labelLandingDesc = new System.Windows.Forms.Label();
            this.labelLandingCopyright = new System.Windows.Forms.Label();
            this.labelLandingDesc3 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.MenuStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // MenuStrip
            // 
            this.MenuStrip.BackColor = System.Drawing.Color.Transparent;
            this.MenuStrip.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.MenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.viewToolStripMenuItem,
            this.loginToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.MenuStrip.Location = new System.Drawing.Point(0, 0);
            this.MenuStrip.Name = "MenuStrip";
            this.MenuStrip.Padding = new System.Windows.Forms.Padding(7, 3, 0, 3);
            this.MenuStrip.Size = new System.Drawing.Size(710, 25);
            this.MenuStrip.TabIndex = 0;
            this.MenuStrip.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripMenuItem1});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F)));
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(55, 19);
            this.fileToolStripMenuItem.Text = "Tệp tin";
            // 
            // exitToolStripMenuItem1
            // 
            this.exitToolStripMenuItem1.BackColor = System.Drawing.SystemColors.Window;
            this.exitToolStripMenuItem1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.exitToolStripMenuItem1.Name = "exitToolStripMenuItem1";
            this.exitToolStripMenuItem1.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.X)));
            this.exitToolStripMenuItem1.Size = new System.Drawing.Size(141, 22);
            this.exitToolStripMenuItem1.Text = "Thoát";
            this.exitToolStripMenuItem1.Click += new System.EventHandler(this.exitToolStripMenuItem1_Click);
            // 
            // viewToolStripMenuItem
            // 
            this.viewToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuItem1ToolStripMenuItem,
            this.toolStripSeparator3,
            this.menuItem2ToolStripMenuItem,
            this.menuItem3ToolStripMenuItem});
            this.viewToolStripMenuItem.Name = "viewToolStripMenuItem";
            this.viewToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.V)));
            this.viewToolStripMenuItem.Size = new System.Drawing.Size(56, 19);
            this.viewToolStripMenuItem.Text = "Dữ liệu";
            // 
            // menuItem1ToolStripMenuItem
            // 
            this.menuItem1ToolStripMenuItem.BackColor = System.Drawing.SystemColors.Window;
            this.menuItem1ToolStripMenuItem.Name = "menuItem1ToolStripMenuItem";
            this.menuItem1ToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.O)));
            this.menuItem1ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.menuItem1ToolStripMenuItem.Text = "Sản phẩm";
            this.menuItem1ToolStripMenuItem.Click += new System.EventHandler(this.menuItem1ToolStripMenuItem_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.BackColor = System.Drawing.SystemColors.Window;
            this.toolStripSeparator3.ForeColor = System.Drawing.SystemColors.Control;
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(177, 6);
            // 
            // menuItem2ToolStripMenuItem
            // 
            this.menuItem2ToolStripMenuItem.BackColor = System.Drawing.SystemColors.Window;
            this.menuItem2ToolStripMenuItem.Name = "menuItem2ToolStripMenuItem";
            this.menuItem2ToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.S)));
            this.menuItem2ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.menuItem2ToolStripMenuItem.Text = "Nhân viên";
            this.menuItem2ToolStripMenuItem.Click += new System.EventHandler(this.menuItem2ToolStripMenuItem_Click);
            // 
            // menuItem3ToolStripMenuItem
            // 
            this.menuItem3ToolStripMenuItem.BackColor = System.Drawing.SystemColors.Window;
            this.menuItem3ToolStripMenuItem.Name = "menuItem3ToolStripMenuItem";
            this.menuItem3ToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.R)));
            this.menuItem3ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.menuItem3ToolStripMenuItem.Text = "Khách hàng";
            this.menuItem3ToolStripMenuItem.Click += new System.EventHandler(this.menuItem3ToolStripMenuItem_Click);
            // 
            // loginToolStripMenuItem
            // 
            this.loginToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.loginToolStripMenuItem1,
            this.logoutToolStripMenuItem});
            this.loginToolStripMenuItem.Name = "loginToolStripMenuItem";
            this.loginToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.A)));
            this.loginToolStripMenuItem.Size = new System.Drawing.Size(65, 19);
            this.loginToolStripMenuItem.Text = "Xác thực";
            // 
            // loginToolStripMenuItem1
            // 
            this.loginToolStripMenuItem1.BackColor = System.Drawing.SystemColors.Window;
            this.loginToolStripMenuItem1.Name = "loginToolStripMenuItem1";
            this.loginToolStripMenuItem1.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.L)));
            this.loginToolStripMenuItem1.Size = new System.Drawing.Size(168, 22);
            this.loginToolStripMenuItem1.Text = "Đăng nhập";
            this.loginToolStripMenuItem1.Click += new System.EventHandler(this.loginToolStripMenuItem1_Click);
            // 
            // logoutToolStripMenuItem
            // 
            this.logoutToolStripMenuItem.BackColor = System.Drawing.SystemColors.Window;
            this.logoutToolStripMenuItem.Name = "logoutToolStripMenuItem";
            this.logoutToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.U)));
            this.logoutToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.logoutToolStripMenuItem.Text = "Đăng xuất";
            this.logoutToolStripMenuItem.Click += new System.EventHandler(this.logoutToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.getTheSampleSQLScriptToolStripMenuItem,
            this.toolStripSeparator1,
            this.aboutToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.H)));
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(62, 19);
            this.helpToolStripMenuItem.Text = "Trợ giúp";
            // 
            // getTheSampleSQLScriptToolStripMenuItem
            // 
            this.getTheSampleSQLScriptToolStripMenuItem.BackColor = System.Drawing.SystemColors.Window;
            this.getTheSampleSQLScriptToolStripMenuItem.Name = "getTheSampleSQLScriptToolStripMenuItem";
            this.getTheSampleSQLScriptToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F1)));
            this.getTheSampleSQLScriptToolStripMenuItem.Size = new System.Drawing.Size(344, 22);
            this.getTheSampleSQLScriptToolStripMenuItem.Text = "Lấy mẫu cơ sở dữ liệu Microsoft SQL Server";
            this.getTheSampleSQLScriptToolStripMenuItem.Click += new System.EventHandler(this.getTheSampleSQLScriptToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.BackColor = System.Drawing.SystemColors.Window;
            this.toolStripSeparator1.ForeColor = System.Drawing.SystemColors.Control;
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(341, 6);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.BackColor = System.Drawing.SystemColors.Window;
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F2)));
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(344, 22);
            this.aboutToolStripMenuItem.Text = "Thông tin ứng dụng";
            this.aboutToolStripMenuItem.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // labelLanding
            // 
            this.labelLanding.AutoSize = true;
            this.labelLanding.BackColor = System.Drawing.Color.Transparent;
            this.labelLanding.Font = new System.Drawing.Font("Segoe UI Semibold", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelLanding.ForeColor = System.Drawing.SystemColors.Highlight;
            this.labelLanding.Location = new System.Drawing.Point(13, 322);
            this.labelLanding.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelLanding.Name = "labelLanding";
            this.labelLanding.Size = new System.Drawing.Size(309, 45);
            this.labelLanding.TabIndex = 1;
            this.labelLanding.Text = "Trình quản lý Vật tư";
            // 
            // labelLandingDesc
            // 
            this.labelLandingDesc.AutoSize = true;
            this.labelLandingDesc.BackColor = System.Drawing.Color.Transparent;
            this.labelLandingDesc.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelLandingDesc.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.labelLandingDesc.Location = new System.Drawing.Point(454, 334);
            this.labelLandingDesc.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelLandingDesc.Name = "labelLandingDesc";
            this.labelLandingDesc.Size = new System.Drawing.Size(243, 15);
            this.labelLandingDesc.TabIndex = 2;
            this.labelLandingDesc.Text = "Chào mừng bạn đến với Trình quản lý Vật tư!\r\n";
            // 
            // labelLandingCopyright
            // 
            this.labelLandingCopyright.AutoSize = true;
            this.labelLandingCopyright.BackColor = System.Drawing.Color.Transparent;
            this.labelLandingCopyright.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelLandingCopyright.Location = new System.Drawing.Point(372, 6);
            this.labelLandingCopyright.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelLandingCopyright.Name = "labelLandingCopyright";
            this.labelLandingCopyright.Size = new System.Drawing.Size(294, 15);
            this.labelLandingCopyright.TabIndex = 3;
            this.labelLandingCopyright.Text = "Copyright string goes here. String defined in Form Init.";
            // 
            // labelLandingDesc3
            // 
            this.labelLandingDesc3.AutoSize = true;
            this.labelLandingDesc3.BackColor = System.Drawing.Color.Transparent;
            this.labelLandingDesc3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelLandingDesc3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.labelLandingDesc3.Location = new System.Drawing.Point(429, 349);
            this.labelLandingDesc3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelLandingDesc3.Name = "labelLandingDesc3";
            this.labelLandingDesc3.Size = new System.Drawing.Size(268, 15);
            this.labelLandingDesc3.TabIndex = 2;
            this.labelLandingDesc3.Text = "Để bắt đầu. Vui lòng chọn Xác thực > Đăng nhập.";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Default;
            this.pictureBox1.Image = global::InventoryMgr.Properties.Resources.backdrop2;
            this.pictureBox1.Location = new System.Drawing.Point(-8, 1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(727, 378);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // MainActivity
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(710, 380);
            this.Controls.Add(this.labelLandingDesc3);
            this.Controls.Add(this.labelLandingDesc);
            this.Controls.Add(this.labelLandingCopyright);
            this.Controls.Add(this.MenuStrip);
            this.Controls.Add(this.labelLanding);
            this.Controls.Add(this.pictureBox1);
            this.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.MenuStrip;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "MainActivity";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Trình quản lý Vật tư";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainActivity_FormClosing);
            this.Load += new System.EventHandler(this.MainActivity_Load);
            this.MenuStrip.ResumeLayout(false);
            this.MenuStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip MenuStrip;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loginToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loginToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem logoutToolStripMenuItem;
        private System.Windows.Forms.Label labelLanding;
        private System.Windows.Forms.Label labelLandingDesc;
        private System.Windows.Forms.ToolStripMenuItem viewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem menuItem2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem menuItem1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem menuItem3ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.Label labelLandingCopyright;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem getTheSampleSQLScriptToolStripMenuItem;
        private System.Windows.Forms.Label labelLandingDesc3;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

