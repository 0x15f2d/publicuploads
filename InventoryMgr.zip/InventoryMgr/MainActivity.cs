﻿using System;
using System.Diagnostics;
using System.Windows.Forms;

namespace InventoryMgr
{
    public partial class MainActivity : Form
    {
        public MainActivity()
        {
            InitializeComponent();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void recordToolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void exitToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            string version = "Phiên bản " + Application.ProductVersion;
            MessageBox.Show("Trình quản lý Vật tư\n" + version, "Thông tin về Trình quản lý Vật tư", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.Show();
        }

        private void loginToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (Globals.IsLoggedIn)
            {
                this.Hide();
                DialogResult dlgResult = MessageBox.Show("Bạn đã đang đăng nhập rồi. Bạn vẫn muốn đăng nhập chứ?", "Từ đã nào", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
                if (dlgResult == DialogResult.Yes)
                {
                    Authorize authorizeform = new Authorize();
                    authorizeform.ShowDialog();
                }
                if (dlgResult == DialogResult.No)
                {
                    this.Show();
                }
            }
            if (Globals.IsLoggedIn == false)
            {
                Authorize authorizeform = new Authorize();
                this.Hide();
                authorizeform.ShowDialog();
            }
        }

        private void MainActivity_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void MainActivity_Load(object sender, EventArgs e)
        {
            int yearNow = DateTime.Now.Year;
            labelLandingCopyright.Text = $"© {yearNow} Le Trung Hung Business Enterprises. Sử dụng nội bộ.";
            if (Globals.IsLoggedIn)
            {
                logoutToolStripMenuItem.Enabled = true;
                viewToolStripMenuItem.Enabled = true;
            }
            if (Globals.IsLoggedIn == false)
            {
                logoutToolStripMenuItem.Enabled = false;
                viewToolStripMenuItem.Enabled = false;
            }
        }

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Authorize authorizeform = new Authorize();
            this.Hide();
            if (DatabaseLogic.DatabaseConnectionState == "Not initialized")
            {
                MessageBox.Show("Bạn không thể đăng xuất khi mà còn chưa đăng nhập.\nTùy chọn này sẽ bị vô hiệu hóa cho đến khi bạn đăng nhập được.", "Không được", MessageBoxButtons.OK, MessageBoxIcon.Error);
                logoutToolStripMenuItem.Enabled = false;
                this.Show();
            }
            else
            {
                // I know, I know this is a dumb fail-safe.
                MessageBox.Show("Bạn đã đăng xuất.", "Xong", MessageBoxButtons.OK, MessageBoxIcon.Information);
                DatabaseLogic.SqlUsername = "";
                DatabaseLogic.SqlPassword = "";
                DatabaseLogic.SqlIntgSec = "false";
                Globals.IsLoggedIn = false;
                logoutToolStripMenuItem.Enabled = false;
                viewToolStripMenuItem.Enabled = false;
                /*DatabaseLogic dbLogic = new DatabaseLogic();
                 dbLogic.CloseConnection();*/
                this.Show();
            }
        }


        /*public void UpdateDebugInfo()
        {
            Globals.DebugConnectionStatus = $@"Server={DatabaseLogic.SqlServer}\{DatabaseLogic.SqlInstance},{DatabaseLogic.SqlPortNo};Network Library={DatabaseLogic.SqlNwkLib};Database={DatabaseLogic.SqlDatabaseName};User ID={DatabaseLogic.SqlUsername};Password=[Redacted];Integrated Security={DatabaseLogic.SqlIntgSec}";
            Globals.ConnectionStatus = $"Login string: {Globals.DebugConnectionStatus}\n\nConnection state: {DatabaseLogic.DatabaseConnectionState}\n\nLogged in: {Globals.IsLoggedIn}";
        }
        private void checkConnectionToDatabaseStatusToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            MessageBox.Show(Globals.DebugConnectionStatus, "Connection variables", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            this.Show();
        }*/

        private void menuItem1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TableList table = new TableList();
            Globals.IsTableProducts = true;
            this.Hide();
            table.ShowDialog();
        }

        private void menuItem2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TableList table = new TableList();
            Globals.IsTableStaff = true;
            this.Hide();
            table.ShowDialog();
        }

        private void menuItem3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TableList table = new TableList();
            Globals.IsTableClients = true;
            this.Hide();
            table.ShowDialog();
        }

        private void getTheSampleSQLScriptToolStripMenuItem_Click(object sender, EventArgs e)
        {
            String Password = "ynF7uMcKFU";
            String URL = "https://pastebin.com/ugM4KGxJ";
            DateTime ExpiryDate = new DateTime(DateTime.Now.Year + 1, DateTime.Now.Month, DateTime.Now.Day, DateTime.Now.Hour, DateTime.Now.Minute, DateTime.Now.Second);
            Process.Start(URL);
            Clipboard.SetText(Password);
            MessageBox.Show($"Đây là liên kết: {URL}\nMật khẩu đã được sao chép vào bảng tạm.\n\nNhấn Ctrl + V để dán.\nLưu ý rằng liên kết này sẽ hết hạn sau ngày {ExpiryDate}.", "Đã mở trình duyệt.", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

    }
}
