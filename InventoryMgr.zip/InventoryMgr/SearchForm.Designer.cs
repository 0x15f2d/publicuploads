﻿namespace InventoryMgr
{
    partial class SearchForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SearchForm));
            this.SearchButton = new System.Windows.Forms.Button();
            this.CancelBtn = new System.Windows.Forms.Button();
            this.FindLabel = new System.Windows.Forms.Label();
            this.SearchIcon = new System.Windows.Forms.PictureBox();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.SearchQueryTextBox = new System.Windows.Forms.TextBox();
            this.ScopeColComboBox = new System.Windows.Forms.ComboBox();
            this.SearchScopeLabel = new System.Windows.Forms.Label();
            this.SearchWhatLabel = new System.Windows.Forms.Label();
            this.ScopeTableComboBox = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.checkBoxAlwaysCloseForm = new System.Windows.Forms.CheckBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.SearchIcon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // SearchButton
            // 
            this.SearchButton.Location = new System.Drawing.Point(266, 190);
            this.SearchButton.Name = "SearchButton";
            this.SearchButton.Size = new System.Drawing.Size(75, 30);
            this.SearchButton.TabIndex = 0;
            this.SearchButton.Text = "Tìm...";
            this.SearchButton.UseVisualStyleBackColor = true;
            this.SearchButton.Click += new System.EventHandler(this.OKButton_Click);
            // 
            // CancelBtn
            // 
            this.CancelBtn.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.CancelBtn.Location = new System.Drawing.Point(347, 190);
            this.CancelBtn.Name = "CancelBtn";
            this.CancelBtn.Size = new System.Drawing.Size(75, 30);
            this.CancelBtn.TabIndex = 1;
            this.CancelBtn.Text = "Hủy";
            this.CancelBtn.UseVisualStyleBackColor = true;
            this.CancelBtn.Click += new System.EventHandler(this.CancelBtn_Click);
            // 
            // FindLabel
            // 
            this.FindLabel.AutoSize = true;
            this.FindLabel.Font = new System.Drawing.Font("Segoe UI Semibold", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FindLabel.ForeColor = System.Drawing.SystemColors.Highlight;
            this.FindLabel.Location = new System.Drawing.Point(12, 22);
            this.FindLabel.Name = "FindLabel";
            this.FindLabel.Size = new System.Drawing.Size(203, 32);
            this.FindLabel.TabIndex = 23;
            this.FindLabel.Text = "Tìm kiếm bản ghi";
            // 
            // SearchIcon
            // 
            this.SearchIcon.Image = global::InventoryMgr.Properties.Resources.Search;
            this.SearchIcon.Location = new System.Drawing.Point(376, 12);
            this.SearchIcon.Name = "SearchIcon";
            this.SearchIcon.Size = new System.Drawing.Size(47, 50);
            this.SearchIcon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.SearchIcon.TabIndex = 21;
            this.SearchIcon.TabStop = false;
            // 
            // SearchQueryTextBox
            // 
            this.SearchQueryTextBox.Location = new System.Drawing.Point(132, 139);
            this.SearchQueryTextBox.Name = "SearchQueryTextBox";
            this.SearchQueryTextBox.Size = new System.Drawing.Size(291, 23);
            this.SearchQueryTextBox.TabIndex = 24;
            this.SearchQueryTextBox.Text = "Search query goes here";
            // 
            // ScopeColComboBox
            // 
            this.ScopeColComboBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ScopeColComboBox.FormattingEnabled = true;
            this.ScopeColComboBox.Location = new System.Drawing.Point(281, 110);
            this.ScopeColComboBox.Name = "ScopeColComboBox";
            this.ScopeColComboBox.Size = new System.Drawing.Size(142, 23);
            this.ScopeColComboBox.TabIndex = 25;
            this.ScopeColComboBox.Text = "Column name goes here";
            // 
            // SearchScopeLabel
            // 
            this.SearchScopeLabel.AutoSize = true;
            this.SearchScopeLabel.Location = new System.Drawing.Point(16, 112);
            this.SearchScopeLabel.Name = "SearchScopeLabel";
            this.SearchScopeLabel.Size = new System.Drawing.Size(103, 15);
            this.SearchScopeLabel.TabIndex = 26;
            this.SearchScopeLabel.Text = "Phạm vi tìm kiếm:";
            // 
            // SearchWhatLabel
            // 
            this.SearchWhatLabel.AutoSize = true;
            this.SearchWhatLabel.Location = new System.Drawing.Point(16, 142);
            this.SearchWhatLabel.Name = "SearchWhatLabel";
            this.SearchWhatLabel.Size = new System.Drawing.Size(103, 15);
            this.SearchWhatLabel.TabIndex = 27;
            this.SearchWhatLabel.Text = "Nội dung cần tìm:";
            // 
            // ScopeTableComboBox
            // 
            this.ScopeTableComboBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ScopeTableComboBox.FormattingEnabled = true;
            this.ScopeTableComboBox.Location = new System.Drawing.Point(132, 110);
            this.ScopeTableComboBox.Name = "ScopeTableComboBox";
            this.ScopeTableComboBox.Size = new System.Drawing.Size(143, 23);
            this.ScopeTableComboBox.TabIndex = 28;
            this.ScopeTableComboBox.Text = "Table name goes here";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(278, 89);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 15);
            this.label1.TabIndex = 29;
            this.label1.Text = "Cột:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(129, 89);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 15);
            this.label2.TabIndex = 30;
            this.label2.Text = "Bảng:";
            // 
            // checkBoxAlwaysCloseForm
            // 
            this.checkBoxAlwaysCloseForm.AutoSize = true;
            this.checkBoxAlwaysCloseForm.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxAlwaysCloseForm.Location = new System.Drawing.Point(18, 196);
            this.checkBoxAlwaysCloseForm.Name = "checkBoxAlwaysCloseForm";
            this.checkBoxAlwaysCloseForm.Size = new System.Drawing.Size(227, 19);
            this.checkBoxAlwaysCloseForm.TabIndex = 32;
            this.checkBoxAlwaysCloseForm.Text = "Luôn đóng cửa sổ tìm kiếm sau khi tìm";
            this.checkBoxAlwaysCloseForm.UseVisualStyleBackColor = true;
            this.checkBoxAlwaysCloseForm.CheckedChanged += new System.EventHandler(this.checkBoxAlwaysCloseForm_CheckedChanged);
            // 
            // label4
            // 
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label4.Location = new System.Drawing.Point(19, 178);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(403, 2);
            this.label4.TabIndex = 34;
            // 
            // label3
            // 
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label3.Location = new System.Drawing.Point(18, 77);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(403, 2);
            this.label3.TabIndex = 35;
            // 
            // SearchForm
            // 
            this.AcceptButton = this.SearchButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.CancelButton = this.CancelBtn;
            this.ClientSize = new System.Drawing.Size(439, 232);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.checkBoxAlwaysCloseForm);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ScopeTableComboBox);
            this.Controls.Add(this.SearchWhatLabel);
            this.Controls.Add(this.SearchScopeLabel);
            this.Controls.Add(this.ScopeColComboBox);
            this.Controls.Add(this.SearchQueryTextBox);
            this.Controls.Add(this.FindLabel);
            this.Controls.Add(this.SearchIcon);
            this.Controls.Add(this.CancelBtn);
            this.Controls.Add(this.SearchButton);
            this.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "SearchForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Tìm kiếm...";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.SearchForm_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.SearchForm_FormClosed);
            this.Load += new System.EventHandler(this.SearchForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.SearchIcon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.BindingSource bindingSource1;
        private System.Windows.Forms.Button SearchButton;
        private System.Windows.Forms.Button CancelBtn;
        private System.Windows.Forms.Label FindLabel;
        private System.Windows.Forms.PictureBox SearchIcon;
        private System.Windows.Forms.TextBox SearchQueryTextBox;
        private System.Windows.Forms.ComboBox ScopeColComboBox;
        private System.Windows.Forms.Label SearchScopeLabel;
        private System.Windows.Forms.Label SearchWhatLabel;
        private System.Windows.Forms.ComboBox ScopeTableComboBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox checkBoxAlwaysCloseForm;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
    }
}