﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace InventoryMgr
{
    public partial class SearchForm : Form
    {
        TableList tableList = new TableList();
        List<Products> SqlProducts = new List<Products>();
        List<Staff> SqlStaff = new List<Staff>();
        List<Clients> SqlClients = new List<Clients>();
        public SearchForm()
        {
            InitializeComponent();
        }

        private void SearchForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Hide();
        }

        private void OKButton_Click(object sender, EventArgs e)
        {
            List<Products> SqlProducts = new List<Products>();
            List<Staff> SqlStaff = new List<Staff>();
            List<Clients> SqlClients = new List<Clients>();
            DatabaseLogic DatabaseLogic = new DatabaseLogic();
            DatabaseLogic.SearchQueryCurrentTable = ScopeTableComboBox.Text;
            DatabaseLogic.SearchQuery = $"SELECT * FROM {DatabaseLogic.SearchQueryCurrentTable} WHERE {ScopeColComboBox.Text} = '{SearchQueryTextBox.Text}'";

            if (SearchQueryTextBox.Text == "")
            {
                MessageBox.Show("Hãy điền truy vấn mà bạn muốn tìm.", "Chưa đủ thông tin", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                try
                {
                    DatabaseLogic.SearchRecord();
                }
                catch (Exception exception)
                {
                    if (exception != null)
                    {
                        MessageBox.Show(exception.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                if (Globals.IsTableProducts)
                {
                    tableList.LoadProductsTable(SqlProducts);
                }
                if (Globals.IsTableStaff)
                {
                    tableList.LoadStaffTable(SqlStaff);
                }
                if (Globals.IsTableClients)
                {
                    tableList.LoadClientsTable(SqlClients);
                }
                if (Globals.SearchBoxAlwaysHide)
                {
                    this.Hide();
                }
            }
        }

        private void CancelBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void SearchForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
        }

        private void SearchForm_Load(object sender, EventArgs e)
        {
            if (Globals.SearchBoxAlwaysHide == true)
            {
                checkBoxAlwaysCloseForm.CheckState = CheckState.Checked;
            }
            else
            {
                checkBoxAlwaysCloseForm.CheckState = CheckState.Unchecked;
            }
            if (Globals.IsTableProducts)
            {
                ScopeTableComboBox.Items.Add("Products");
                ScopeColComboBox.Items.Add("ProductID");
                ScopeColComboBox.Items.Add("ProductName");
                ScopeColComboBox.Items.Add("ProductSKU");
                ScopeColComboBox.Items.Add("ProductQuantity");
                ScopeColComboBox.Items.Add("ProductPrice");
                ScopeColComboBox.Items.Add("ProductStaffIDProvision");
                ScopeColComboBox.Items.Add("ProductExpiryDate");
                ScopeColComboBox.Items.Add("ProductImportDate");
                ScopeTableComboBox.Text = "Products";
                ScopeColComboBox.Text = "ProductID";
                SearchQueryTextBox.Text = "";
            }
            if (Globals.IsTableStaff)
            {
                ScopeTableComboBox.Items.Add("Staff");
                ScopeColComboBox.Items.Add("StaffID");
                ScopeColComboBox.Items.Add("StaffIsAdmin");
                ScopeColComboBox.Items.Add("StaffName");
                ScopeColComboBox.Items.Add("StaffBirthday");
                ScopeColComboBox.Items.Add("StaffAddress");
                ScopeColComboBox.Items.Add("StaffPhone");
                ScopeColComboBox.Items.Add("StaffEmail");
                ScopeColComboBox.Items.Add("StaffNotes");
                ScopeTableComboBox.Text = "Staff";
                ScopeColComboBox.Text = "StaffID";
            }
            if (Globals.IsTableClients)
            {
                ScopeTableComboBox.Items.Add("Clients");
                ScopeColComboBox.Items.Add("ClientID");
                ScopeColComboBox.Items.Add("ClientName");
                ScopeColComboBox.Items.Add("ClientBirthday");
                ScopeColComboBox.Items.Add("ClientAddress");
                ScopeColComboBox.Items.Add("ClientPhone");
                ScopeColComboBox.Items.Add("ClientEmail");
                ScopeColComboBox.Items.Add("ClientNotes");
                ScopeTableComboBox.Text = "Clients";
                ScopeColComboBox.Text = "ClientID";
            }
        }

        private void checkBoxAlwaysCloseForm_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxAlwaysCloseForm.CheckState == CheckState.Checked)
            {
                Globals.SearchBoxAlwaysHide = true;
            }
            else
            {
                Globals.SearchBoxAlwaysHide = false;
            }
        }
    }
}
