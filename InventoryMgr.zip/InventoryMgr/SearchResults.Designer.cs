﻿namespace InventoryMgr
{
    partial class SearchResults
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SearchResults));
            this.ResultDataGrid = new System.Windows.Forms.DataGridView();
            this.SearchIcon = new System.Windows.Forms.PictureBox();
            this.labelTableName = new System.Windows.Forms.Label();
            this.labelColName = new System.Windows.Forms.Label();
            this.labelFrom = new System.Windows.Forms.Label();
            this.CancelBtn = new System.Windows.Forms.Button();
            this.labelSearch = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.ResultDataGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SearchIcon)).BeginInit();
            this.SuspendLayout();
            // 
            // ResultDataGrid
            // 
            this.ResultDataGrid.BackgroundColor = System.Drawing.SystemColors.Window;
            this.ResultDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ResultDataGrid.Location = new System.Drawing.Point(167, 91);
            this.ResultDataGrid.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.ResultDataGrid.Name = "ResultDataGrid";
            this.ResultDataGrid.Size = new System.Drawing.Size(757, 421);
            this.ResultDataGrid.TabIndex = 0;
            this.ResultDataGrid.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.ResultDataGrid_CellContentClick);
            // 
            // SearchIcon
            // 
            this.SearchIcon.BackColor = System.Drawing.Color.Transparent;
            this.SearchIcon.Image = global::InventoryMgr.Properties.Resources.Search;
            this.SearchIcon.Location = new System.Drawing.Point(1, 0);
            this.SearchIcon.Name = "SearchIcon";
            this.SearchIcon.Size = new System.Drawing.Size(158, 519);
            this.SearchIcon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.SearchIcon.TabIndex = 22;
            this.SearchIcon.TabStop = false;
            // 
            // labelTableName
            // 
            this.labelTableName.AutoSize = true;
            this.labelTableName.BackColor = System.Drawing.Color.Transparent;
            this.labelTableName.Font = new System.Drawing.Font("Segoe UI Semibold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTableName.ForeColor = System.Drawing.SystemColors.Highlight;
            this.labelTableName.Location = new System.Drawing.Point(448, 11);
            this.labelTableName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelTableName.Name = "labelTableName";
            this.labelTableName.Size = new System.Drawing.Size(222, 30);
            this.labelTableName.TabIndex = 23;
            this.labelTableName.Text = "Table name goes here";
            // 
            // labelColName
            // 
            this.labelColName.AutoSize = true;
            this.labelColName.BackColor = System.Drawing.Color.Transparent;
            this.labelColName.Font = new System.Drawing.Font("Segoe UI Semibold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelColName.ForeColor = System.Drawing.SystemColors.Highlight;
            this.labelColName.Location = new System.Drawing.Point(235, 41);
            this.labelColName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelColName.Name = "labelColName";
            this.labelColName.Size = new System.Drawing.Size(246, 30);
            this.labelColName.TabIndex = 24;
            this.labelColName.Text = "Column name goes here";
            // 
            // labelFrom
            // 
            this.labelFrom.AutoSize = true;
            this.labelFrom.BackColor = System.Drawing.Color.Transparent;
            this.labelFrom.Font = new System.Drawing.Font("Segoe UI Semibold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelFrom.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.labelFrom.Location = new System.Drawing.Point(166, 41);
            this.labelFrom.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelFrom.Name = "labelFrom";
            this.labelFrom.Size = new System.Drawing.Size(75, 30);
            this.labelFrom.TabIndex = 25;
            this.labelFrom.Text = "Từ cột";
            // 
            // CancelBtn
            // 
            this.CancelBtn.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.CancelBtn.Location = new System.Drawing.Point(846, 28);
            this.CancelBtn.Name = "CancelBtn";
            this.CancelBtn.Size = new System.Drawing.Size(75, 30);
            this.CancelBtn.TabIndex = 26;
            this.CancelBtn.Text = "Đóng";
            this.CancelBtn.UseVisualStyleBackColor = true;
            this.CancelBtn.Click += new System.EventHandler(this.CancelBtn_Click);
            // 
            // labelSearch
            // 
            this.labelSearch.AutoSize = true;
            this.labelSearch.BackColor = System.Drawing.Color.Transparent;
            this.labelSearch.Font = new System.Drawing.Font("Segoe UI Semibold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSearch.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.labelSearch.Location = new System.Drawing.Point(165, 11);
            this.labelSearch.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelSearch.Name = "labelSearch";
            this.labelSearch.Size = new System.Drawing.Size(292, 30);
            this.labelSearch.TabIndex = 27;
            this.labelSearch.Text = "Kết quả tìm kiếm trong bảng";
            // 
            // SearchResults
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.CancelBtn;
            this.ClientSize = new System.Drawing.Size(933, 519);
            this.Controls.Add(this.labelTableName);
            this.Controls.Add(this.labelSearch);
            this.Controls.Add(this.CancelBtn);
            this.Controls.Add(this.labelFrom);
            this.Controls.Add(this.labelColName);
            this.Controls.Add(this.SearchIcon);
            this.Controls.Add(this.ResultDataGrid);
            this.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "SearchResults";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Két quả tìm kiếm";
            this.TopMost = true;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.SearchResults_FormClosing);
            this.Load += new System.EventHandler(this.SearchResults_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ResultDataGrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SearchIcon)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView ResultDataGrid;
        private System.Windows.Forms.PictureBox SearchIcon;
        private System.Windows.Forms.Label labelTableName;
        private System.Windows.Forms.Label labelColName;
        private System.Windows.Forms.Label labelFrom;
        private System.Windows.Forms.Button CancelBtn;
        private System.Windows.Forms.Label labelSearch;
    }
}