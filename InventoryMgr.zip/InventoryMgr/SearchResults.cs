﻿using System.Data;
using System.Windows.Forms;

namespace InventoryMgr
{
    public partial class SearchResults : Form
    {
        public SearchResults(DataTable dataTable)
        {
            InitializeComponent();
            ResultDataGrid.DataSource = dataTable;
        }

        private void SearchResults_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
        }

        private void ResultDataGrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void SearchResults_Load(object sender, System.EventArgs e)
        {

            if (Globals.IsTableProducts)
            {
                labelTableName.Text = "Products";
                labelColName.Text = "ProductID";
            }
            if (Globals.IsTableStaff)
            {
                labelTableName.Text = "Staff";
                labelColName.Text = "StaffID";
            }
            if (Globals.IsTableClients)
            {
                labelTableName.Text = "Clients";
                labelColName.Text = "ClientID";
            }
        }

        private void CancelBtn_Click(object sender, System.EventArgs e)
        {
            this.Hide();
        }
    }
}
