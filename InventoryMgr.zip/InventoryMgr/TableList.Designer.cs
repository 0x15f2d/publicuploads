﻿namespace InventoryMgr
{
    partial class TableList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TableList));
            this.tableStaff = new System.Windows.Forms.ListView();
            this.colStaffID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colStaffIsAdmin = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colStaffName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colStaffBirthday = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colStaffAddress = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colStaffPhone = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colStaffEmail = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colStaffNotes = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.findRecordsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.closeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpTopicsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.whyCantIEditFromTheSampleDatabaseYouProvidedToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.AddRecordButton = new System.Windows.Forms.Button();
            this.DeleteButton = new System.Windows.Forms.Button();
            this.tableClients = new System.Windows.Forms.ListView();
            this.colClientID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colClientName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colClientBirthday = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colClientAddress = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colClientPhone = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colClientEmail = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colClientNotes = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tableProducts = new System.Windows.Forms.ListView();
            this.colProductID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colProductName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colProductSKU = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colProductQuantity = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colProductPrice = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colProductStaffIDProvision = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colProductExpiryDate = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colProductImportDate = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label1 = new System.Windows.Forms.Label();
            this.labelTableName = new System.Windows.Forms.Label();
            this.EditButton = new System.Windows.Forms.Button();
            this.textBoxItem1 = new System.Windows.Forms.TextBox();
            this.labelItem1 = new System.Windows.Forms.Label();
            this.textBoxItem2 = new System.Windows.Forms.TextBox();
            this.labelItem2 = new System.Windows.Forms.Label();
            this.textBoxItem3 = new System.Windows.Forms.TextBox();
            this.labelItem3 = new System.Windows.Forms.Label();
            this.textBoxItem4 = new System.Windows.Forms.TextBox();
            this.labelItem4 = new System.Windows.Forms.Label();
            this.textBoxItem5 = new System.Windows.Forms.TextBox();
            this.labelItem5 = new System.Windows.Forms.Label();
            this.textBoxItem10 = new System.Windows.Forms.TextBox();
            this.labelItem10 = new System.Windows.Forms.Label();
            this.textBoxItem9 = new System.Windows.Forms.TextBox();
            this.labelItem9 = new System.Windows.Forms.Label();
            this.textBoxItem8 = new System.Windows.Forms.TextBox();
            this.labelItem8 = new System.Windows.Forms.Label();
            this.textBoxItem7 = new System.Windows.Forms.TextBox();
            this.labelItem7 = new System.Windows.Forms.Label();
            this.textBoxItem6 = new System.Windows.Forms.TextBox();
            this.labelItem6 = new System.Windows.Forms.Label();
            this.textBoxItem15 = new System.Windows.Forms.TextBox();
            this.labelItem15 = new System.Windows.Forms.Label();
            this.textBoxItem14 = new System.Windows.Forms.TextBox();
            this.labelItem14 = new System.Windows.Forms.Label();
            this.textBoxItem13 = new System.Windows.Forms.TextBox();
            this.labelItem13 = new System.Windows.Forms.Label();
            this.textBoxItem12 = new System.Windows.Forms.TextBox();
            this.labelItem12 = new System.Windows.Forms.Label();
            this.textBoxItem11 = new System.Windows.Forms.TextBox();
            this.labelItem11 = new System.Windows.Forms.Label();
            this.textBoxItem16 = new System.Windows.Forms.TextBox();
            this.labelItem16 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.CloseButton = new System.Windows.Forms.Button();
            this.ClearAllTextButton = new System.Windows.Forms.Button();
            this.RecordsIcon = new System.Windows.Forms.PictureBox();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.RecordsIcon)).BeginInit();
            this.SuspendLayout();
            // 
            // tableStaff
            // 
            this.tableStaff.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.tableStaff.AutoArrange = false;
            this.tableStaff.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.colStaffID,
            this.colStaffIsAdmin,
            this.colStaffName,
            this.colStaffBirthday,
            this.colStaffAddress,
            this.colStaffPhone,
            this.colStaffEmail,
            this.colStaffNotes});
            this.tableStaff.HideSelection = false;
            this.tableStaff.Location = new System.Drawing.Point(404, 26);
            this.tableStaff.Name = "tableStaff";
            this.tableStaff.Size = new System.Drawing.Size(619, 522);
            this.tableStaff.TabIndex = 0;
            this.tableStaff.UseCompatibleStateImageBehavior = false;
            this.tableStaff.View = System.Windows.Forms.View.Details;
            this.tableStaff.SelectedIndexChanged += new System.EventHandler(this.StaffTable_SelectedIndexChanged);
            // 
            // colStaffID
            // 
            this.colStaffID.Text = "Mã nhân viên";
            this.colStaffID.Width = 46;
            // 
            // colStaffIsAdmin
            // 
            this.colStaffIsAdmin.Text = "Là quản trị viên?";
            this.colStaffIsAdmin.Width = 130;
            // 
            // colStaffName
            // 
            this.colStaffName.Text = "Tên nhân viên";
            this.colStaffName.Width = 131;
            // 
            // colStaffBirthday
            // 
            this.colStaffBirthday.Text = "Ngày sinh";
            this.colStaffBirthday.Width = 124;
            // 
            // colStaffAddress
            // 
            this.colStaffAddress.Text = "Địa chỉ";
            this.colStaffAddress.Width = 141;
            // 
            // colStaffPhone
            // 
            this.colStaffPhone.Text = "Điện thoại";
            this.colStaffPhone.Width = 146;
            // 
            // colStaffEmail
            // 
            this.colStaffEmail.Text = "Email";
            this.colStaffEmail.Width = 153;
            // 
            // colStaffNotes
            // 
            this.colStaffNotes.Text = "Ghi chú";
            this.colStaffNotes.Width = 206;
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.Window;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1035, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.BackColor = System.Drawing.SystemColors.Window;
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.findRecordsToolStripMenuItem,
            this.toolStripSeparator3,
            this.closeToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F)));
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(55, 20);
            this.fileToolStripMenuItem.Text = "Tệp tin";
            // 
            // findRecordsToolStripMenuItem
            // 
            this.findRecordsToolStripMenuItem.Name = "findRecordsToolStripMenuItem";
            this.findRecordsToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.F)));
            this.findRecordsToolStripMenuItem.Size = new System.Drawing.Size(215, 22);
            this.findRecordsToolStripMenuItem.Text = "Tìm kiếm bản ghi...";
            this.findRecordsToolStripMenuItem.Click += new System.EventHandler(this.findRecordsToolStripMenuItem_Click_1);
            // 
            // closeToolStripMenuItem
            // 
            this.closeToolStripMenuItem.BackColor = System.Drawing.SystemColors.Control;
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.X)));
            this.closeToolStripMenuItem.Size = new System.Drawing.Size(215, 22);
            this.closeToolStripMenuItem.Text = "Đóng";
            this.closeToolStripMenuItem.Click += new System.EventHandler(this.closeToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.BackColor = System.Drawing.SystemColors.Window;
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.helpTopicsToolStripMenuItem,
            this.whyCantIEditFromTheSampleDatabaseYouProvidedToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.H)));
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(64, 20);
            this.helpToolStripMenuItem.Text = "Tại sao...";
            // 
            // helpTopicsToolStripMenuItem
            // 
            this.helpTopicsToolStripMenuItem.BackColor = System.Drawing.SystemColors.Control;
            this.helpTopicsToolStripMenuItem.Name = "helpTopicsToolStripMenuItem";
            this.helpTopicsToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F1)));
            this.helpTopicsToolStripMenuItem.Size = new System.Drawing.Size(522, 22);
            this.helpTopicsToolStripMenuItem.Text = "Chương trình không bắt một số lỗi nhất định?";
            this.helpTopicsToolStripMenuItem.Click += new System.EventHandler(this.helpTopicsToolStripMenuItem_Click);
            // 
            // whyCantIEditFromTheSampleDatabaseYouProvidedToolStripMenuItem
            // 
            this.whyCantIEditFromTheSampleDatabaseYouProvidedToolStripMenuItem.BackColor = System.Drawing.SystemColors.Control;
            this.whyCantIEditFromTheSampleDatabaseYouProvidedToolStripMenuItem.Name = "whyCantIEditFromTheSampleDatabaseYouProvidedToolStripMenuItem";
            this.whyCantIEditFromTheSampleDatabaseYouProvidedToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F2)));
            this.whyCantIEditFromTheSampleDatabaseYouProvidedToolStripMenuItem.Size = new System.Drawing.Size(522, 22);
            this.whyCantIEditFromTheSampleDatabaseYouProvidedToolStripMenuItem.Text = "Tôi không thể sửa hoặc xóa từ Mẫu Cơ sở dữ liệu mà chương trình cung cấp?";
            this.whyCantIEditFromTheSampleDatabaseYouProvidedToolStripMenuItem.Click += new System.EventHandler(this.whyCantIEditFromTheSampleDatabaseYouProvidedToolStripMenuItem_Click);
            // 
            // AddRecordButton
            // 
            this.AddRecordButton.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddRecordButton.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.AddRecordButton.Location = new System.Drawing.Point(404, 555);
            this.AddRecordButton.Name = "AddRecordButton";
            this.AddRecordButton.Size = new System.Drawing.Size(75, 28);
            this.AddRecordButton.TabIndex = 2;
            this.AddRecordButton.Text = "Thêm";
            this.AddRecordButton.UseVisualStyleBackColor = true;
            this.AddRecordButton.Click += new System.EventHandler(this.AddRecordButton_Click);
            // 
            // DeleteButton
            // 
            this.DeleteButton.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DeleteButton.ForeColor = System.Drawing.Color.Red;
            this.DeleteButton.Location = new System.Drawing.Point(948, 554);
            this.DeleteButton.Name = "DeleteButton";
            this.DeleteButton.Size = new System.Drawing.Size(75, 28);
            this.DeleteButton.TabIndex = 8;
            this.DeleteButton.Text = "Xóa";
            this.DeleteButton.UseVisualStyleBackColor = true;
            this.DeleteButton.Click += new System.EventHandler(this.DeleteButton_Click);
            // 
            // tableClients
            // 
            this.tableClients.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.tableClients.AutoArrange = false;
            this.tableClients.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.colClientID,
            this.colClientName,
            this.colClientBirthday,
            this.colClientAddress,
            this.colClientPhone,
            this.colClientEmail,
            this.colClientNotes});
            this.tableClients.HideSelection = false;
            this.tableClients.Location = new System.Drawing.Point(404, 24);
            this.tableClients.Name = "tableClients";
            this.tableClients.Size = new System.Drawing.Size(619, 522);
            this.tableClients.TabIndex = 9;
            this.tableClients.UseCompatibleStateImageBehavior = false;
            this.tableClients.View = System.Windows.Forms.View.Details;
            this.tableClients.SelectedIndexChanged += new System.EventHandler(this.ClientsTable_SelectedIndexChanged);
            // 
            // colClientID
            // 
            this.colClientID.Text = "Mã khách hàng";
            this.colClientID.Width = 45;
            // 
            // colClientName
            // 
            this.colClientName.Text = "Tên khách hàng";
            this.colClientName.Width = 151;
            // 
            // colClientBirthday
            // 
            this.colClientBirthday.Text = "Ngày sinh";
            this.colClientBirthday.Width = 112;
            // 
            // colClientAddress
            // 
            this.colClientAddress.Text = "Địa chỉ";
            this.colClientAddress.Width = 123;
            // 
            // colClientPhone
            // 
            this.colClientPhone.Text = "Số điện thoại";
            this.colClientPhone.Width = 141;
            // 
            // colClientEmail
            // 
            this.colClientEmail.Text = "Email";
            this.colClientEmail.Width = 152;
            // 
            // colClientNotes
            // 
            this.colClientNotes.Text = "Ghi chú";
            // 
            // tableProducts
            // 
            this.tableProducts.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.tableProducts.AutoArrange = false;
            this.tableProducts.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.colProductID,
            this.colProductName,
            this.colProductSKU,
            this.colProductQuantity,
            this.colProductPrice,
            this.colProductStaffIDProvision,
            this.colProductExpiryDate,
            this.colProductImportDate});
            this.tableProducts.HideSelection = false;
            this.tableProducts.Location = new System.Drawing.Point(404, 25);
            this.tableProducts.Name = "tableProducts";
            this.tableProducts.Size = new System.Drawing.Size(619, 522);
            this.tableProducts.TabIndex = 10;
            this.tableProducts.UseCompatibleStateImageBehavior = false;
            this.tableProducts.View = System.Windows.Forms.View.Details;
            this.tableProducts.SelectedIndexChanged += new System.EventHandler(this.ProductsList_SelectedIndexChanged);
            // 
            // colProductID
            // 
            this.colProductID.Text = "Mã SP";
            this.colProductID.Width = 46;
            // 
            // colProductName
            // 
            this.colProductName.Text = "Tên sản phẩm";
            this.colProductName.Width = 151;
            // 
            // colProductSKU
            // 
            this.colProductSKU.Text = "Đơn vị giữ hàng (SKU)";
            this.colProductSKU.Width = 74;
            // 
            // colProductQuantity
            // 
            this.colProductQuantity.Text = "SLg.";
            this.colProductQuantity.Width = 36;
            // 
            // colProductPrice
            // 
            this.colProductPrice.Text = "Giá";
            this.colProductPrice.Width = 32;
            // 
            // colProductStaffIDProvision
            // 
            this.colProductStaffIDProvision.Text = "NV Quản lý SP";
            this.colProductStaffIDProvision.Width = 91;
            // 
            // colProductExpiryDate
            // 
            this.colProductExpiryDate.Text = "Ngày hết hạn";
            this.colProductExpiryDate.Width = 84;
            // 
            // colProductImportDate
            // 
            this.colProductImportDate.Text = "Ngày nhập hàng";
            this.colProductImportDate.Width = 102;
            // 
            // label1
            // 
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Location = new System.Drawing.Point(16, 94);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(380, 2);
            this.label1.TabIndex = 19;
            // 
            // labelTableName
            // 
            this.labelTableName.AutoSize = true;
            this.labelTableName.Font = new System.Drawing.Font("Segoe UI Semibold", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTableName.ForeColor = System.Drawing.SystemColors.Highlight;
            this.labelTableName.Location = new System.Drawing.Point(16, 37);
            this.labelTableName.Name = "labelTableName";
            this.labelTableName.Size = new System.Drawing.Size(253, 32);
            this.labelTableName.TabIndex = 20;
            this.labelTableName.Text = "Table name goes here";
            // 
            // EditButton
            // 
            this.EditButton.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EditButton.Location = new System.Drawing.Point(487, 555);
            this.EditButton.Name = "EditButton";
            this.EditButton.Size = new System.Drawing.Size(75, 28);
            this.EditButton.TabIndex = 3;
            this.EditButton.Text = "Sửa";
            this.EditButton.UseVisualStyleBackColor = true;
            this.EditButton.Click += new System.EventHandler(this.EditButton_Click);
            // 
            // textBoxItem1
            // 
            this.textBoxItem1.Location = new System.Drawing.Point(178, 108);
            this.textBoxItem1.Name = "textBoxItem1";
            this.textBoxItem1.Size = new System.Drawing.Size(194, 23);
            this.textBoxItem1.TabIndex = 33;
            this.textBoxItem1.WordWrap = false;
            // 
            // labelItem1
            // 
            this.labelItem1.AutoSize = true;
            this.labelItem1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelItem1.Location = new System.Drawing.Point(42, 110);
            this.labelItem1.Name = "labelItem1";
            this.labelItem1.Size = new System.Drawing.Size(13, 15);
            this.labelItem1.TabIndex = 32;
            this.labelItem1.Text = "1";
            // 
            // textBoxItem2
            // 
            this.textBoxItem2.Location = new System.Drawing.Point(178, 135);
            this.textBoxItem2.Name = "textBoxItem2";
            this.textBoxItem2.Size = new System.Drawing.Size(194, 23);
            this.textBoxItem2.TabIndex = 35;
            this.textBoxItem2.WordWrap = false;
            // 
            // labelItem2
            // 
            this.labelItem2.AutoSize = true;
            this.labelItem2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelItem2.Location = new System.Drawing.Point(42, 138);
            this.labelItem2.Name = "labelItem2";
            this.labelItem2.Size = new System.Drawing.Size(13, 15);
            this.labelItem2.TabIndex = 34;
            this.labelItem2.Text = "2";
            // 
            // textBoxItem3
            // 
            this.textBoxItem3.Location = new System.Drawing.Point(178, 162);
            this.textBoxItem3.Name = "textBoxItem3";
            this.textBoxItem3.Size = new System.Drawing.Size(194, 23);
            this.textBoxItem3.TabIndex = 37;
            this.textBoxItem3.WordWrap = false;
            // 
            // labelItem3
            // 
            this.labelItem3.AutoSize = true;
            this.labelItem3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelItem3.Location = new System.Drawing.Point(42, 165);
            this.labelItem3.Name = "labelItem3";
            this.labelItem3.Size = new System.Drawing.Size(13, 15);
            this.labelItem3.TabIndex = 36;
            this.labelItem3.Text = "3";
            // 
            // textBoxItem4
            // 
            this.textBoxItem4.Location = new System.Drawing.Point(178, 189);
            this.textBoxItem4.Name = "textBoxItem4";
            this.textBoxItem4.Size = new System.Drawing.Size(194, 23);
            this.textBoxItem4.TabIndex = 39;
            this.textBoxItem4.WordWrap = false;
            // 
            // labelItem4
            // 
            this.labelItem4.AutoSize = true;
            this.labelItem4.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelItem4.Location = new System.Drawing.Point(42, 192);
            this.labelItem4.Name = "labelItem4";
            this.labelItem4.Size = new System.Drawing.Size(13, 15);
            this.labelItem4.TabIndex = 38;
            this.labelItem4.Text = "4";
            // 
            // textBoxItem5
            // 
            this.textBoxItem5.Location = new System.Drawing.Point(178, 216);
            this.textBoxItem5.Name = "textBoxItem5";
            this.textBoxItem5.Size = new System.Drawing.Size(194, 23);
            this.textBoxItem5.TabIndex = 41;
            this.textBoxItem5.WordWrap = false;
            // 
            // labelItem5
            // 
            this.labelItem5.AutoSize = true;
            this.labelItem5.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelItem5.Location = new System.Drawing.Point(42, 219);
            this.labelItem5.Name = "labelItem5";
            this.labelItem5.Size = new System.Drawing.Size(13, 15);
            this.labelItem5.TabIndex = 40;
            this.labelItem5.Text = "5";
            // 
            // textBoxItem10
            // 
            this.textBoxItem10.Location = new System.Drawing.Point(178, 352);
            this.textBoxItem10.Name = "textBoxItem10";
            this.textBoxItem10.Size = new System.Drawing.Size(194, 23);
            this.textBoxItem10.TabIndex = 51;
            this.textBoxItem10.WordWrap = false;
            // 
            // labelItem10
            // 
            this.labelItem10.AutoSize = true;
            this.labelItem10.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelItem10.Location = new System.Drawing.Point(42, 355);
            this.labelItem10.Name = "labelItem10";
            this.labelItem10.Size = new System.Drawing.Size(19, 15);
            this.labelItem10.TabIndex = 50;
            this.labelItem10.Text = "10";
            // 
            // textBoxItem9
            // 
            this.textBoxItem9.Location = new System.Drawing.Point(178, 328);
            this.textBoxItem9.Name = "textBoxItem9";
            this.textBoxItem9.Size = new System.Drawing.Size(194, 23);
            this.textBoxItem9.TabIndex = 49;
            this.textBoxItem9.WordWrap = false;
            // 
            // labelItem9
            // 
            this.labelItem9.AutoSize = true;
            this.labelItem9.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelItem9.Location = new System.Drawing.Point(42, 328);
            this.labelItem9.Name = "labelItem9";
            this.labelItem9.Size = new System.Drawing.Size(13, 15);
            this.labelItem9.TabIndex = 48;
            this.labelItem9.Text = "9";
            // 
            // textBoxItem8
            // 
            this.textBoxItem8.Location = new System.Drawing.Point(178, 298);
            this.textBoxItem8.Name = "textBoxItem8";
            this.textBoxItem8.Size = new System.Drawing.Size(194, 23);
            this.textBoxItem8.TabIndex = 47;
            this.textBoxItem8.WordWrap = false;
            // 
            // labelItem8
            // 
            this.labelItem8.AutoSize = true;
            this.labelItem8.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelItem8.Location = new System.Drawing.Point(42, 301);
            this.labelItem8.Name = "labelItem8";
            this.labelItem8.Size = new System.Drawing.Size(13, 15);
            this.labelItem8.TabIndex = 46;
            this.labelItem8.Text = "8";
            // 
            // textBoxItem7
            // 
            this.textBoxItem7.Location = new System.Drawing.Point(178, 271);
            this.textBoxItem7.Name = "textBoxItem7";
            this.textBoxItem7.Size = new System.Drawing.Size(194, 23);
            this.textBoxItem7.TabIndex = 45;
            this.textBoxItem7.WordWrap = false;
            // 
            // labelItem7
            // 
            this.labelItem7.AutoSize = true;
            this.labelItem7.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelItem7.Location = new System.Drawing.Point(42, 274);
            this.labelItem7.Name = "labelItem7";
            this.labelItem7.Size = new System.Drawing.Size(13, 15);
            this.labelItem7.TabIndex = 44;
            this.labelItem7.Text = "7";
            // 
            // textBoxItem6
            // 
            this.textBoxItem6.Location = new System.Drawing.Point(178, 244);
            this.textBoxItem6.Name = "textBoxItem6";
            this.textBoxItem6.Size = new System.Drawing.Size(194, 23);
            this.textBoxItem6.TabIndex = 43;
            this.textBoxItem6.WordWrap = false;
            // 
            // labelItem6
            // 
            this.labelItem6.AutoSize = true;
            this.labelItem6.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelItem6.Location = new System.Drawing.Point(42, 246);
            this.labelItem6.Name = "labelItem6";
            this.labelItem6.Size = new System.Drawing.Size(13, 15);
            this.labelItem6.TabIndex = 42;
            this.labelItem6.Text = "6";
            // 
            // textBoxItem15
            // 
            this.textBoxItem15.Location = new System.Drawing.Point(178, 487);
            this.textBoxItem15.Name = "textBoxItem15";
            this.textBoxItem15.Size = new System.Drawing.Size(194, 23);
            this.textBoxItem15.TabIndex = 61;
            this.textBoxItem15.WordWrap = false;
            // 
            // labelItem15
            // 
            this.labelItem15.AutoSize = true;
            this.labelItem15.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelItem15.Location = new System.Drawing.Point(42, 490);
            this.labelItem15.Name = "labelItem15";
            this.labelItem15.Size = new System.Drawing.Size(19, 15);
            this.labelItem15.TabIndex = 60;
            this.labelItem15.Text = "15";
            // 
            // textBoxItem14
            // 
            this.textBoxItem14.Location = new System.Drawing.Point(178, 460);
            this.textBoxItem14.Name = "textBoxItem14";
            this.textBoxItem14.Size = new System.Drawing.Size(194, 23);
            this.textBoxItem14.TabIndex = 59;
            this.textBoxItem14.WordWrap = false;
            // 
            // labelItem14
            // 
            this.labelItem14.AutoSize = true;
            this.labelItem14.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelItem14.Location = new System.Drawing.Point(42, 463);
            this.labelItem14.Name = "labelItem14";
            this.labelItem14.Size = new System.Drawing.Size(19, 15);
            this.labelItem14.TabIndex = 58;
            this.labelItem14.Text = "14";
            // 
            // textBoxItem13
            // 
            this.textBoxItem13.Location = new System.Drawing.Point(178, 433);
            this.textBoxItem13.Name = "textBoxItem13";
            this.textBoxItem13.Size = new System.Drawing.Size(194, 23);
            this.textBoxItem13.TabIndex = 57;
            this.textBoxItem13.WordWrap = false;
            // 
            // labelItem13
            // 
            this.labelItem13.AutoSize = true;
            this.labelItem13.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelItem13.Location = new System.Drawing.Point(42, 436);
            this.labelItem13.Name = "labelItem13";
            this.labelItem13.Size = new System.Drawing.Size(19, 15);
            this.labelItem13.TabIndex = 56;
            this.labelItem13.Text = "13";
            // 
            // textBoxItem12
            // 
            this.textBoxItem12.Location = new System.Drawing.Point(178, 406);
            this.textBoxItem12.Name = "textBoxItem12";
            this.textBoxItem12.Size = new System.Drawing.Size(194, 23);
            this.textBoxItem12.TabIndex = 55;
            this.textBoxItem12.WordWrap = false;
            // 
            // labelItem12
            // 
            this.labelItem12.AutoSize = true;
            this.labelItem12.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelItem12.Location = new System.Drawing.Point(42, 408);
            this.labelItem12.Name = "labelItem12";
            this.labelItem12.Size = new System.Drawing.Size(19, 15);
            this.labelItem12.TabIndex = 54;
            this.labelItem12.Text = "12";
            // 
            // textBoxItem11
            // 
            this.textBoxItem11.Location = new System.Drawing.Point(178, 378);
            this.textBoxItem11.Name = "textBoxItem11";
            this.textBoxItem11.Size = new System.Drawing.Size(194, 23);
            this.textBoxItem11.TabIndex = 53;
            this.textBoxItem11.WordWrap = false;
            // 
            // labelItem11
            // 
            this.labelItem11.AutoSize = true;
            this.labelItem11.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelItem11.Location = new System.Drawing.Point(42, 381);
            this.labelItem11.Name = "labelItem11";
            this.labelItem11.Size = new System.Drawing.Size(19, 15);
            this.labelItem11.TabIndex = 52;
            this.labelItem11.Text = "11";
            // 
            // textBoxItem16
            // 
            this.textBoxItem16.Location = new System.Drawing.Point(178, 514);
            this.textBoxItem16.Name = "textBoxItem16";
            this.textBoxItem16.Size = new System.Drawing.Size(194, 23);
            this.textBoxItem16.TabIndex = 63;
            this.textBoxItem16.WordWrap = false;
            // 
            // labelItem16
            // 
            this.labelItem16.AutoSize = true;
            this.labelItem16.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelItem16.Location = new System.Drawing.Point(42, 517);
            this.labelItem16.Name = "labelItem16";
            this.labelItem16.Size = new System.Drawing.Size(19, 15);
            this.labelItem16.TabIndex = 62;
            this.labelItem16.Text = "16";
            // 
            // label2
            // 
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label2.Location = new System.Drawing.Point(16, 545);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(380, 2);
            this.label2.TabIndex = 64;
            // 
            // CloseButton
            // 
            this.CloseButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.CloseButton.Location = new System.Drawing.Point(22, 555);
            this.CloseButton.Name = "CloseButton";
            this.CloseButton.Size = new System.Drawing.Size(67, 28);
            this.CloseButton.TabIndex = 65;
            this.CloseButton.Text = "Đóng";
            this.CloseButton.UseVisualStyleBackColor = true;
            this.CloseButton.Click += new System.EventHandler(this.CloseButton_Click);
            // 
            // ClearAllTextButton
            // 
            this.ClearAllTextButton.Location = new System.Drawing.Point(178, 555);
            this.ClearAllTextButton.Name = "ClearAllTextButton";
            this.ClearAllTextButton.Size = new System.Drawing.Size(194, 28);
            this.ClearAllTextButton.TabIndex = 66;
            this.ClearAllTextButton.Text = "Làm trống tất cả các trường";
            this.ClearAllTextButton.UseVisualStyleBackColor = true;
            this.ClearAllTextButton.Click += new System.EventHandler(this.ClearAllTextButton_Click);
            // 
            // RecordsIcon
            // 
            this.RecordsIcon.Image = global::InventoryMgr.Properties.Resources.edit;
            this.RecordsIcon.Location = new System.Drawing.Point(325, 27);
            this.RecordsIcon.Name = "RecordsIcon";
            this.RecordsIcon.Size = new System.Drawing.Size(47, 50);
            this.RecordsIcon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.RecordsIcon.TabIndex = 18;
            this.RecordsIcon.TabStop = false;
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.BackColor = System.Drawing.SystemColors.Control;
            this.toolStripSeparator3.ForeColor = System.Drawing.SystemColors.Control;
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(212, 6);
            // 
            // TableList
            // 
            this.AcceptButton = this.AddRecordButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.CancelButton = this.CloseButton;
            this.ClientSize = new System.Drawing.Size(1035, 592);
            this.Controls.Add(this.ClearAllTextButton);
            this.Controls.Add(this.CloseButton);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBoxItem16);
            this.Controls.Add(this.labelItem16);
            this.Controls.Add(this.textBoxItem15);
            this.Controls.Add(this.labelItem15);
            this.Controls.Add(this.textBoxItem14);
            this.Controls.Add(this.labelItem14);
            this.Controls.Add(this.textBoxItem13);
            this.Controls.Add(this.labelItem13);
            this.Controls.Add(this.textBoxItem12);
            this.Controls.Add(this.labelItem12);
            this.Controls.Add(this.textBoxItem11);
            this.Controls.Add(this.labelItem11);
            this.Controls.Add(this.textBoxItem10);
            this.Controls.Add(this.labelItem10);
            this.Controls.Add(this.textBoxItem9);
            this.Controls.Add(this.labelItem9);
            this.Controls.Add(this.textBoxItem8);
            this.Controls.Add(this.labelItem8);
            this.Controls.Add(this.textBoxItem7);
            this.Controls.Add(this.labelItem7);
            this.Controls.Add(this.textBoxItem6);
            this.Controls.Add(this.labelItem6);
            this.Controls.Add(this.textBoxItem5);
            this.Controls.Add(this.labelItem5);
            this.Controls.Add(this.textBoxItem4);
            this.Controls.Add(this.labelItem4);
            this.Controls.Add(this.textBoxItem3);
            this.Controls.Add(this.labelItem3);
            this.Controls.Add(this.textBoxItem2);
            this.Controls.Add(this.labelItem2);
            this.Controls.Add(this.textBoxItem1);
            this.Controls.Add(this.labelItem1);
            this.Controls.Add(this.labelTableName);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.RecordsIcon);
            this.Controls.Add(this.tableProducts);
            this.Controls.Add(this.tableClients);
            this.Controls.Add(this.DeleteButton);
            this.Controls.Add(this.EditButton);
            this.Controls.Add(this.AddRecordButton);
            this.Controls.Add(this.tableStaff);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.WindowText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "TableList";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cơ sở dữ liệu";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.TableList_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.TableList_FormClosed);
            this.Load += new System.EventHandler(this.TableList_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.RecordsIcon)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView tableStaff;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem closeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpTopicsToolStripMenuItem;
        private System.Windows.Forms.Button AddRecordButton;
        private System.Windows.Forms.Button DeleteButton;
        private System.Windows.Forms.ListView tableClients;
        private System.Windows.Forms.ListView tableProducts;
        private System.Windows.Forms.PictureBox RecordsIcon;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelTableName;
        private System.Windows.Forms.Button EditButton;
        private System.Windows.Forms.TextBox textBoxItem1;
        private System.Windows.Forms.Label labelItem1;
        private System.Windows.Forms.TextBox textBoxItem2;
        private System.Windows.Forms.Label labelItem2;
        private System.Windows.Forms.TextBox textBoxItem3;
        private System.Windows.Forms.Label labelItem3;
        private System.Windows.Forms.TextBox textBoxItem4;
        private System.Windows.Forms.Label labelItem4;
        private System.Windows.Forms.TextBox textBoxItem5;
        private System.Windows.Forms.Label labelItem5;
        private System.Windows.Forms.TextBox textBoxItem10;
        private System.Windows.Forms.Label labelItem10;
        private System.Windows.Forms.TextBox textBoxItem9;
        private System.Windows.Forms.Label labelItem9;
        private System.Windows.Forms.TextBox textBoxItem8;
        private System.Windows.Forms.Label labelItem8;
        private System.Windows.Forms.TextBox textBoxItem7;
        private System.Windows.Forms.Label labelItem7;
        private System.Windows.Forms.TextBox textBoxItem6;
        private System.Windows.Forms.Label labelItem6;
        private System.Windows.Forms.TextBox textBoxItem15;
        private System.Windows.Forms.Label labelItem15;
        private System.Windows.Forms.TextBox textBoxItem14;
        private System.Windows.Forms.Label labelItem14;
        private System.Windows.Forms.TextBox textBoxItem13;
        private System.Windows.Forms.Label labelItem13;
        private System.Windows.Forms.TextBox textBoxItem12;
        private System.Windows.Forms.Label labelItem12;
        private System.Windows.Forms.TextBox textBoxItem11;
        private System.Windows.Forms.Label labelItem11;
        private System.Windows.Forms.TextBox textBoxItem16;
        private System.Windows.Forms.Label labelItem16;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ToolStripMenuItem whyCantIEditFromTheSampleDatabaseYouProvidedToolStripMenuItem;
        private System.Windows.Forms.Button CloseButton;
        private System.Windows.Forms.Button ClearAllTextButton;
        private System.Windows.Forms.ToolStripMenuItem findRecordsToolStripMenuItem;
        private System.Windows.Forms.ColumnHeader colProductID;
        private System.Windows.Forms.ColumnHeader colProductName;
        private System.Windows.Forms.ColumnHeader colProductSKU;
        private System.Windows.Forms.ColumnHeader colProductQuantity;
        private System.Windows.Forms.ColumnHeader colProductPrice;
        private System.Windows.Forms.ColumnHeader colProductStaffIDProvision;
        private System.Windows.Forms.ColumnHeader colProductExpiryDate;
        private System.Windows.Forms.ColumnHeader colProductImportDate;
        private System.Windows.Forms.ColumnHeader colClientID;
        private System.Windows.Forms.ColumnHeader colClientName;
        private System.Windows.Forms.ColumnHeader colClientBirthday;
        private System.Windows.Forms.ColumnHeader colClientAddress;
        private System.Windows.Forms.ColumnHeader colClientPhone;
        private System.Windows.Forms.ColumnHeader colClientEmail;
        private System.Windows.Forms.ColumnHeader colClientNotes;
        private System.Windows.Forms.ColumnHeader colStaffID;
        private System.Windows.Forms.ColumnHeader colStaffIsAdmin;
        private System.Windows.Forms.ColumnHeader colStaffName;
        private System.Windows.Forms.ColumnHeader colStaffBirthday;
        private System.Windows.Forms.ColumnHeader colStaffAddress;
        private System.Windows.Forms.ColumnHeader colStaffPhone;
        private System.Windows.Forms.ColumnHeader colStaffEmail;
        private System.Windows.Forms.ColumnHeader colStaffNotes;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
    }
}