﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace InventoryMgr
{
    public partial class TableList : Form
    {
        //  These lists Refers to Classes defined in DatabaseValues.cs
        List<Products> ProductTable = new List<Products>();
        List<Staff> StaffTable = new List<Staff>();
        List<Clients> ClientsTable = new List<Clients>();
        DatabaseLogic DatabaseLogic = new DatabaseLogic();
        public void ShowLabels(bool logic)
        {
            labelItem1.Visible = logic;
            labelItem2.Visible = logic;
            labelItem3.Visible = logic;
            labelItem4.Visible = logic;
            labelItem5.Visible = logic;
            labelItem6.Visible = logic;
            labelItem7.Visible = logic;
            labelItem8.Visible = logic;
            labelItem9.Visible = logic;
            labelItem10.Visible = logic;
            labelItem11.Visible = logic;
            labelItem12.Visible = logic;
            labelItem13.Visible = logic;
            labelItem14.Visible = logic;
            labelItem15.Visible = logic;
            labelItem16.Visible = logic;
        }
        public void ClearTextBox()
        {
            textBoxItem1.Text = "";
            textBoxItem2.Text = "";
            textBoxItem3.Text = "";
            textBoxItem4.Text = "";
            textBoxItem5.Text = "";
            textBoxItem6.Text = "";
            textBoxItem7.Text = "";
            textBoxItem8.Text = "";
            textBoxItem9.Text = "";
            textBoxItem10.Text = "";
            textBoxItem11.Text = "";
            textBoxItem12.Text = "";
            textBoxItem13.Text = "";
            textBoxItem14.Text = "";
            textBoxItem15.Text = "";
            textBoxItem16.Text = "";
        }
        public void ShowTextBox(bool logic)
        {
            textBoxItem1.Visible = logic;
            textBoxItem2.Visible = logic;
            textBoxItem3.Visible = logic;
            textBoxItem4.Visible = logic;
            textBoxItem5.Visible = logic;
            textBoxItem6.Visible = logic;
            textBoxItem7.Visible = logic;
            textBoxItem8.Visible = logic;
            textBoxItem9.Visible = logic;
            textBoxItem10.Visible = logic;
            textBoxItem11.Visible = logic;
            textBoxItem12.Visible = logic;
            textBoxItem13.Visible = logic;
            textBoxItem14.Visible = logic;
            textBoxItem15.Visible = logic;
            textBoxItem16.Visible = logic;
        }
        public void InitializeClientsTableEdit()
        {
            labelTableName.Text = "Khách hàng";
            labelItem1.Visible = true;
            labelItem2.Visible = true;
            labelItem3.Visible = true;
            labelItem4.Visible = true;
            labelItem5.Visible = true;
            labelItem6.Visible = true;
            labelItem7.Visible = true;
            textBoxItem1.Visible = true;
            textBoxItem2.Visible = true;
            textBoxItem3.Visible = true;
            textBoxItem4.Visible = true;
            textBoxItem5.Visible = true;
            textBoxItem6.Visible = true;
            textBoxItem7.Visible = true;
            labelItem1.Text = colClientID.Text;
            labelItem2.Text = colClientName.Text;
            labelItem3.Text = colClientBirthday.Text;
            labelItem4.Text = colClientAddress.Text;
            labelItem5.Text = colClientPhone.Text;
            labelItem6.Text = colClientEmail.Text;
            labelItem7.Text = colClientNotes.Text;
        }
        public void InitializeStaffTableEdit()
        {
            labelTableName.Text = "Nhân viên";
            labelItem1.Visible = true;
            labelItem2.Visible = true;
            labelItem3.Visible = true;
            labelItem4.Visible = true;
            labelItem5.Visible = true;
            labelItem6.Visible = true;
            labelItem7.Visible = true;
            labelItem8.Visible = true;
            textBoxItem1.Visible = true;
            textBoxItem2.Visible = true;
            textBoxItem3.Visible = true;
            textBoxItem4.Visible = true;
            textBoxItem5.Visible = true;
            textBoxItem6.Visible = true;
            textBoxItem7.Visible = true;
            textBoxItem8.Visible = true;
            labelItem1.Text = colStaffID.Text;
            labelItem2.Text = colStaffIsAdmin.Text;
            labelItem3.Text = colStaffName.Text;
            labelItem4.Text = colStaffBirthday.Text;
            labelItem5.Text = colStaffAddress.Text;
            labelItem6.Text = colStaffPhone.Text;
            labelItem7.Text = colStaffEmail.Text;
            labelItem8.Text = colStaffNotes.Text;
        }
        public void InitializeProductsTableEdit()
        {
            labelTableName.Text = "Sản phẩm";
            labelItem1.Visible = true;
            labelItem2.Visible = true;
            labelItem3.Visible = true;
            labelItem4.Visible = true;
            labelItem5.Visible = true;
            labelItem6.Visible = true;
            labelItem7.Visible = true;
            labelItem8.Visible = true;
            textBoxItem1.Visible = true;
            textBoxItem2.Visible = true;
            textBoxItem3.Visible = true;
            textBoxItem4.Visible = true;
            textBoxItem5.Visible = true;
            textBoxItem6.Visible = true;
            textBoxItem7.Visible = true;
            textBoxItem8.Visible = true;
            labelItem1.Text = colProductID.Text;
            labelItem2.Text = colProductName.Text;
            labelItem3.Text = colProductSKU.Text;
            labelItem4.Text = colProductQuantity.Text;
            labelItem5.Text = colProductPrice.Text;
            labelItem6.Text = colProductStaffIDProvision.Text;
            labelItem7.Text = colProductExpiryDate.Text;
            labelItem8.Text = colProductImportDate.Text;
        }
        public void InvalidateTableVisibility()
        {
            Globals.IsTableProducts = false;
            Globals.IsTableStaff = false;
            Globals.IsTableClients = false;
        }
        public TableList()
        {
            InitializeComponent();
        }
        public void LoadProductsTable(List<Products> ProductsTable)
        {
            tableProducts.Items.Clear();
            for (int i = 0; i < ProductsTable.Count; i++)
            {
                ListViewItem listView = new ListViewItem(Convert.ToString(ProductsTable[i].ProductID));
                listView.SubItems.Add(ProductsTable[i].ProductName);
                listView.SubItems.Add(ProductsTable[i].ProductSKU);
                listView.SubItems.Add(Convert.ToString(ProductsTable[i].ProductQuantity));
                listView.SubItems.Add(Convert.ToString(ProductsTable[i].ProductPrice));
                listView.SubItems.Add(Convert.ToString(ProductsTable[i].ProductStaffIDProvision));
                listView.SubItems.Add(Convert.ToString(ProductsTable[i].ProductExpiryDate));
                listView.SubItems.Add(Convert.ToString(ProductsTable[i].ProductImportDate));
                tableProducts.Items.Add(listView);
            }
        }
        public void LoadStaffTable(List<Staff> StaffTable)
        {
            tableStaff.Items.Clear();
            for (int i = 0; i < StaffTable.Count; i++)
            {
                ListViewItem listView = new ListViewItem(Convert.ToString(StaffTable[i].StaffID));
                listView.SubItems.Add(Convert.ToString(StaffTable[i].StaffIsAdmin));
                listView.SubItems.Add(StaffTable[i].StaffName);
                listView.SubItems.Add(Convert.ToString(StaffTable[i].StaffBirthday));
                listView.SubItems.Add(StaffTable[i].StaffAddress);
                listView.SubItems.Add(StaffTable[i].StaffPhone);
                listView.SubItems.Add(StaffTable[i].StaffEmail);
                listView.SubItems.Add(StaffTable[i].StaffNotes);
                tableStaff.Items.Add(listView);
            }
        }
        public void LoadClientsTable(List<Clients> ClientsTable)
        {
            tableClients.Items.Clear();
            for (int i = 0; i < ClientsTable.Count; i++)
            {
                ListViewItem listView = new ListViewItem(Convert.ToString(ClientsTable[i].ClientID));
                listView.SubItems.Add(ClientsTable[i].ClientName);
                listView.SubItems.Add(Convert.ToString(ClientsTable[i].ClientBirthday));
                listView.SubItems.Add(ClientsTable[i].ClientAddress);
                listView.SubItems.Add(ClientsTable[i].ClientPhone);
                listView.SubItems.Add(ClientsTable[i].ClientEmail);
                listView.SubItems.Add(ClientsTable[i].ClientNotes);
                tableClients.Items.Add(listView);
            }
        }

        private void TableList_Load(object sender, EventArgs e)
        {
            //  For now, this will be disabled.
            findRecordsToolStripMenuItem.Enabled = true;
            ShowTextBox(false);
            ShowLabels(false);
            tableStaff.Visible = false;
            tableClients.Visible = false;
            tableProducts.Visible = false;
            if (Globals.IsTableProducts == true)
            {
                DatabaseLogic.SqlTableName = "Products";
                InitializeProductsTableEdit();
                tableProducts.Visible = true;
                //  ProductTable refers to the top
                ProductTable = DatabaseLogic.GetProductsTable();
                LoadProductsTable(ProductTable);
            }
            if (Globals.IsTableStaff == true)
            {
                DatabaseLogic.SqlTableName = "Staff";
                InitializeStaffTableEdit();
                tableStaff.Visible = true;
                //  StaffTable refers to the top
                StaffTable = DatabaseLogic.GetStaffTable();
                LoadStaffTable(StaffTable);
            }
            if (Globals.IsTableClients == true)
            {
                DatabaseLogic.SqlTableName = "Clients";
                InitializeClientsTableEdit();
                tableClients.Visible = true;
                //  ClientsTable refers to the top
                ClientsTable = DatabaseLogic.GetClientsTable();
                LoadClientsTable(ClientsTable);
            }
        }

        private void helpTopicsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Chương trình đang trong giai đoạn phát triển, chúng tôi dùng trình gỡ lỗi mặc định của .NET để dễ tìm ra nơi chúng tôi gặp lỗi này ở đâu và cải thiện chúng trong phiên bản tiếp theo.", "Trợ giúp", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void TableList_FormClosing(object sender, FormClosingEventArgs e)
        {
            InvalidateTableVisibility();
        }

        private void TableList_FormClosed(object sender, FormClosedEventArgs e)
        {
            InvalidateTableVisibility();
            this.Close();
            MainActivity home = new MainActivity();
            home.Show();
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            InvalidateTableVisibility();
            this.Close();
        }

        private void AddRecordButton_Click(object sender, EventArgs e)
        {
            DatabaseLogic.SqlEditingMode = false;
            if (Globals.IsTableProducts)
            {
                DialogResult dlgResult = MessageBox.Show("Bạn sẽ không thể hoàn tác lại khi nhấn Đồng ý.", "Bạn chắc chứ?", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dlgResult == DialogResult.Yes)
                {
                    ModifyRecordProductsTable();
                }
                else
                {
                    MessageBox.Show("Không có gì thay đổi.", "Xong", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            if (Globals.IsTableStaff)
            {
                DialogResult dlgResult = MessageBox.Show("Bạn sẽ không thể hoàn tác lại khi nhấn Đồng ý.", "Bạn chắc chứ?", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dlgResult == DialogResult.Yes)
                {
                    ModifyRecordStaffTable();
                }
                else
                {
                    MessageBox.Show("Không có gì thay đổi.", "Xong", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            if (Globals.IsTableClients)
            {
                DialogResult dlgResult = MessageBox.Show("Bạn sẽ không thể hoàn tác lại khi nhấn Đồng ý.", "Bạn chắc chứ?", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dlgResult == DialogResult.Yes)
                {
                    ModifyRecordClientsTable();
                }
                else
                {
                    MessageBox.Show("Không có gì thay đổi.", "Xong", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }


        private void EditButton_Click(object sender, EventArgs e)
        {
            DatabaseLogic.SqlEditingMode = true;
            if (Globals.IsTableProducts)
            {
                DialogResult dlgResult = MessageBox.Show("Bạn sẽ không thể hoàn tác lại khi nhấn Đồng ý.", "Bạn chắc chứ?", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dlgResult == DialogResult.Yes)
                {
                    ModifyRecordProductsTable();

                }
                else
                {
                    MessageBox.Show("Không có gì thay đổi.", "Xong", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            if (Globals.IsTableStaff)
            {
                DialogResult dlgResult = MessageBox.Show("Bạn sẽ không thể hoàn tác lại khi nhấn Đồng ý.", "Bạn chắc chứ?", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dlgResult == DialogResult.Yes)
                {
                    ModifyRecordStaffTable();
                }
                else
                {
                    MessageBox.Show("Không có gì thay đổi.", "Xong", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            if (Globals.IsTableClients)
            {
                DialogResult dlgResult = MessageBox.Show("Bạn sẽ không thể hoàn tác lại khi nhấn Đồng ý.", "Bạn chắc chứ?", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dlgResult == DialogResult.Yes)
                {
                    ModifyRecordClientsTable();
                }
                else
                {
                    MessageBox.Show("Không có gì thay đổi.", "Xong", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void DeleteButton_Click(object sender, EventArgs e)
        {
            if (Globals.IsTableProducts)
            {
                DialogResult dlgResult = MessageBox.Show("Bạn sẽ không thể hoàn tác lại khi nhấn Đồng ý.", "Bạn chắc chứ?", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dlgResult == DialogResult.Yes)
                {
                    DeleteRecordProductTable();
                }
                else
                {
                    MessageBox.Show("Không có gì thay đổi.", "Xong", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            if (Globals.IsTableStaff)
            {
                DialogResult dlgResult = MessageBox.Show("Bạn sẽ không thể hoàn tác lại khi nhấn Đồng ý.", "Bạn chắc chứ?", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dlgResult == DialogResult.Yes)
                {
                    DeleteRecordStaffTable();
                }
                else
                {
                    MessageBox.Show("Không có gì thay đổi.", "Xong", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            if (Globals.IsTableClients)
            {
                DialogResult dlgResult = MessageBox.Show("Bạn sẽ không thể hoàn tác lại khi nhấn Đồng ý.", "Bạn chắc chứ?", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dlgResult == DialogResult.Yes)
                {
                    DeleteRecordClientsTable();
                }
                else
                {
                    MessageBox.Show("Không có gì thay đổi.", "Xong", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        public void DeleteRecordProductTable()
        {
            DatabaseLogic.SqlTableName = "Products";
            DatabaseLogic.SqlColName = "ProductID";
            if (tableProducts.SelectedItems.Count > 0)
            {
                //  In DatabaseLogic.DeleteRecord. It assumes the first Column as ID and Deleting the Row by ID.
                //  In this context. Item #0 Means ProductID.
                ListViewItem TableItem = tableProducts.SelectedItems[0];
                DatabaseLogic.DeleteRecord(TableItem.SubItems[0].Text);
                for (int i = 0; i < ProductTable.Count; i++)
                {
                    if (ProductTable[i].ProductID == Convert.ToInt32(TableItem.SubItems[0].Text))
                    {
                        ProductTable.Remove(ProductTable[i]);
                    }
                }
                LoadProductsTable(ProductTable);
                ClearTextBox();
            }
            else if (tableProducts.SelectedItems.Count == 0)
            {
                MessageBox.Show("Không có gì để xóa.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public void DeleteRecordStaffTable()
        {
            DatabaseLogic.SqlTableName = "Staff";
            DatabaseLogic.SqlColName = "StaffID";
            if (tableStaff.SelectedItems.Count > 0)
            {
                //  In DatabaseLogic.DeleteRecord. It assumes the first Column as ID and Deleting the Row by ID.
                //  In this context. Item #0 Means StaffID.
                ListViewItem TableItem = tableStaff.SelectedItems[0];
                DatabaseLogic.DeleteRecord(TableItem.SubItems[0].Text);
                for (int i = 0; i < StaffTable.Count; i++)
                {
                    if (StaffTable[i].StaffID == Convert.ToInt32(TableItem.SubItems[0].Text))
                    {
                        StaffTable.Remove(StaffTable[i]);
                    }
                }
                LoadStaffTable(StaffTable);
                ClearTextBox();
            }
            else if (tableStaff.SelectedItems.Count == 0)
            {
                MessageBox.Show("Không có gì để xóa.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public void DeleteRecordClientsTable()
        {
            DatabaseLogic.SqlTableName = "Clients";
            DatabaseLogic.SqlColName = "ClientID";
            if (tableClients.SelectedItems.Count > 0)
            {
                //  In DatabaseLogic.DeleteRecord. It assumes the first Column as ID and Deleting the Row by ID.
                //  In this context. Item #0 Means StaffID.
                ListViewItem TableItem = tableClients.SelectedItems[0];
                DatabaseLogic.DeleteRecord(TableItem.SubItems[0].Text);
                for (int i = 0; i < ClientsTable.Count; i++)
                {
                    if (ClientsTable[i].ClientID == Convert.ToInt32(TableItem.SubItems[0].Text))
                    {
                        ClientsTable.Remove(ClientsTable[i]);
                    }
                }
                LoadClientsTable(ClientsTable);
                ClearTextBox();
            }
            else if (tableClients.SelectedItems.Count == 0)
            {
                MessageBox.Show("Không có gì để xóa.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public void ModifyRecordClientsTable()
        {
            if (textBoxItem1.Text == "" || textBoxItem2.Text == "" || textBoxItem3.Text == "" || textBoxItem4.Text == "" || textBoxItem5.Text == "" || textBoxItem6.Text == "" || textBoxItem7.Text == "")
            {
                MessageBox.Show("Vui lòng điền tất cả thông tin trước khi thao tác.", "Chưa đủ thông tin", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                //  Convert the Data Types from String to Original SQL data type back to the SQL
                //  Clients refers the class in DatabaseValues
                Clients Items = new Clients(Convert.ToInt32(textBoxItem1.Text), textBoxItem2.Text, Convert.ToDateTime(textBoxItem3.Text), textBoxItem4.Text, textBoxItem5.Text, textBoxItem6.Text, textBoxItem7.Text);
                DatabaseLogic.ModifyClientsTable(Items);
                if (DatabaseLogic.SqlEditingMode == false)
                {
                    ClientsTable.Add(Items);
                }
                // ClearTextBox();
                LoadClientsTable(ClientsTable);
            }
        }
        public void ModifyRecordStaffTable()
        {
            if (textBoxItem1.Text == "" || textBoxItem2.Text == "" || textBoxItem3.Text == "" || textBoxItem4.Text == "" || textBoxItem5.Text == "" || textBoxItem6.Text == "" || textBoxItem7.Text == "" || textBoxItem8.Text == "")
            {
                MessageBox.Show("Vui lòng điền tất cả thông tin trước khi thao tác.", "Chưa đủ thông tin", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                //  Convert the Data Types from String to Original SQL data type back to the SQL
                //  Staff refers the class in DatabaseValues
                Staff Items = new Staff(Convert.ToInt32(textBoxItem1.Text), Convert.ToBoolean(textBoxItem2.Text), textBoxItem3.Text, Convert.ToDateTime(textBoxItem4.Text), textBoxItem5.Text, textBoxItem6.Text, textBoxItem7.Text, textBoxItem8.Text);
                DatabaseLogic.ModifyStaffTable(Items);
                if (DatabaseLogic.SqlEditingMode == false)
                {
                    StaffTable.Add(Items);
                }
                // ClearTextBox();
                LoadStaffTable(StaffTable);
            }
        }
        public void ModifyRecordProductsTable()
        {
            //  TextBox6 is blankable because Expiry Date is Optional.
            if (textBoxItem1.Text == "" || textBoxItem2.Text == "" || textBoxItem3.Text == "" || textBoxItem4.Text == "" || textBoxItem5.Text == "" || textBoxItem7.Text == "" || textBoxItem8.Text == "")
            {
                MessageBox.Show("Vui lòng điền tất cả thông tin trước khi thao tác.", "Chưa đủ thông tin", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                //  Convert the Data Types from String to Original SQL data type back to the SQL
                //  Products refers the class in DatabaseValues
                Products Items = new Products(Convert.ToInt32(textBoxItem1.Text), textBoxItem2.Text, textBoxItem3.Text, Convert.ToInt16(textBoxItem4.Text), Convert.ToDecimal(textBoxItem5.Text), Convert.ToInt32(textBoxItem6.Text), Convert.ToDateTime(textBoxItem7.Text), Convert.ToDateTime(textBoxItem8.Text));
                DatabaseLogic.ModifyProductsTable(Items);
                if (DatabaseLogic.SqlEditingMode == false)
                {
                    ProductTable.Add(Items);
                }
                // ClearTextBox();
                LoadProductsTable(ProductTable);
            }
        }
        private void ProductsList_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (tableProducts.SelectedItems.Count > 0)
            {
                ListViewItem listView = tableProducts.SelectedItems[0];
                string ProductID = listView.SubItems[0].Text;
                string ProductName = listView.SubItems[1].Text;
                string ProductSKU = listView.SubItems[2].Text;
                string ProductQuantity = listView.SubItems[3].Text;
                string ProductPrice = listView.SubItems[4].Text;
                string ProductStaffIDProvision = listView.SubItems[5].Text;
                string ProductExpiryDate = listView.SubItems[6].Text;
                string ProductImportDate = listView.SubItems[7].Text;
                textBoxItem1.Text = ProductID;
                textBoxItem2.Text = ProductName;
                textBoxItem3.Text = ProductSKU;
                textBoxItem4.Text = ProductQuantity;
                textBoxItem5.Text = ProductPrice;
                textBoxItem6.Text = ProductStaffIDProvision;
                textBoxItem7.Text = ProductExpiryDate;
                textBoxItem8.Text = ProductImportDate;
            }
            else
            {
                ClearTextBox();
            }
        }

        private void ClientsTable_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (tableClients.SelectedItems.Count > 0)
            {
                ListViewItem listView = tableClients.SelectedItems[0];
                string ClientID = listView.SubItems[0].Text;
                string ClientName = listView.SubItems[1].Text;
                string ClientBirthday = listView.SubItems[2].Text;
                string ClientAddress = listView.SubItems[3].Text;
                string ClientPhone = listView.SubItems[4].Text;
                string ClientEmail = listView.SubItems[5].Text;
                string ClientNotes = listView.SubItems[6].Text;
                textBoxItem1.Text = ClientID;
                textBoxItem2.Text = ClientName;
                textBoxItem3.Text = ClientBirthday;
                textBoxItem4.Text = ClientAddress;
                textBoxItem5.Text = ClientPhone;
                textBoxItem6.Text = ClientEmail;
                textBoxItem7.Text = ClientNotes;
            }
            else
            {
                ClearTextBox();
            }
        }

        private void StaffTable_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (tableStaff.SelectedItems.Count > 0)
            {
                ListViewItem listView = tableStaff.SelectedItems[0];
                string StaffID = listView.SubItems[0].Text;
                string StaffIsAdmin = listView.SubItems[1].Text;
                string StaffName = listView.SubItems[2].Text;
                string StaffBirthday = listView.SubItems[3].Text;
                string StaffAddress = listView.SubItems[4].Text;
                string StaffPhone = listView.SubItems[5].Text;
                string StaffEmail = listView.SubItems[6].Text;
                string StaffNotes = listView.SubItems[7].Text;
                textBoxItem1.Text = StaffID;
                textBoxItem2.Text = StaffIsAdmin;
                textBoxItem3.Text = StaffName;
                textBoxItem4.Text = StaffBirthday;
                textBoxItem5.Text = StaffAddress;
                textBoxItem6.Text = StaffPhone;
                textBoxItem7.Text = StaffEmail;
                textBoxItem8.Text = StaffNotes;
            }
            else
            {
                ClearTextBox();
            }
        }

        private void whyCantIEditFromTheSampleDatabaseYouProvidedToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Mẫu cơ sở dữ liệu có các ràng buộc nhất định ở các bảng khác.\n\nCó thể bạn không có quyền thể sửa hoặc xóa chúng trừ khi bạn gỡ bỏ ràng buộc đó.", "Trợ giúp", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void CloseButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ClearAllTextButton_Click(object sender, EventArgs e)
        {
            ClearTextBox();
        }

        private void findRecordsToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            SearchForm searchForm = new SearchForm();
            searchForm.Show();
        }
    }
}
